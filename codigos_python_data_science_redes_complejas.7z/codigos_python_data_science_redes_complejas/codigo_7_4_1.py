# -*- coding: utf-8 -*-

import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

def grafo_erdos_renyi(n,m):
    g=nx.Graph()
    for i in range(n):
        u=g.add_node(i)

    for i in range(m):
        a=np.random.randint(n)
        b=np.random.randint(n)
        if a!=b and (a,b) not in g.edges() and (b,a) not in g.edges():
            g.add_edge(a,b)
    pos=nx.spectral_layout(g)
    nx.draw(g,node_size=40)
    plt.title(u'Grafo Erdos-Renyi de '+str(n)+' nodos y '+str(m)+' arcos')
    plt.savefig('grafo_erdos_renyi.png',dpi=400)
    grados=[]
    for v in g.nodes():
        grados.append(g.degree(v))

    plt.figure()
    plt.hist(grados)
    plt.xlabel('Grado nodal')
    plt.ylabel(u'Numero de nodos')
    plt.title(u'Distribucion del grado nodal de un \n'u'grafo Erdos-Renyi de '+str(n)+
	' nodos y '+str(m)+' arcos')
    plt.savefig('distribucion_erdos_renyi.png',dpi=400)


    return g
