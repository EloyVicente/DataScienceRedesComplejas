# -*- coding: utf-8 -*-

from matplotlib import pyplot as plt
import numpy as np
import scipy
from sklearn.cluster import DBSCAN

n=100
X=scipy.zeros([5*n,2])

for i in range(n):

    X[i,0]=np.random.normal(4, 0.25)
    X[i,1]=np.random.normal(4, 0.25)

for i in range(n):

    X[i+n,0]=np.random.normal(1, 0.25)
    X[i+n,1]=np.random.normal(1, 0.25)

for i in range(n):

    X[i+2*n,0]=np.random.normal(2, 0.25)
    X[i+2*n,1]=np.random.normal(2.5, 0.25)

for i in range(n):

    X[i+3*n,0]=np.random.normal(1, 0.25)
    X[i+3*n,1]=np.random.normal(4, 0.25)

for i in range(n):

    X[i+4*n,0]=np.random.normal(4, 0.25)
    X[i+4*n,1]=np.random.normal(1, 0.25)

def dbscan(k,m):

    db = DBSCAN(eps=k, min_samples=m).fit(X)
    core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
    core_samples_mask[db.core_sample_indices_] = True
    labels = db.labels_

    n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)

    return n_clusters_

r=np.array(range(20))
x=np.linspace(0,1,20)
k=0.05
figuras=[]

for i in range(20):
    r[i]=dbscan(k,m=10)
    k=k+0.05

t=np.array(range(15))
m=5

for i in range(15):
    t[i]=dbscan(0.4,m=i)


figura=plt.figure()

axes=plt.subplot(121)
axes.set_ylim([0, 10])
plt.plot(x,r)
plt.xlabel('eps')
plt.ylabel(u'numero de clusters')
plt.title(u'DBSCAN n. de clusters vs radio eps')

axes=plt.subplot(122)
axes.set_ylim([0, 10])
plt.plot(range(5,20),t)
plt.xlabel('MinPt')
plt.ylabel(u'numero de clusters')
plt.title(u'DBSCAN n. de clusters vs radio MinPt')

plt.show(figura)


