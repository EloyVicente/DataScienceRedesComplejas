# -*- coding: utf-8 -*-

import numpy as np
from matplotlib import pyplot as plt

concebido =[165, 140, 154, 139, 134, 154, 120, 133, 150, 146, 140, 114,
            128, 131, 116, 128, 122, 129, 145, 117, 140, 149, 116, 147,
            125, 149, 129, 157, 144, 123, 107, 129, 152, 164, 134, 120,
            148, 151, 149, 138, 159, 169, 137, 151, 141, 145, 135, 135,
            153, 125, 159, 148, 142, 130, 111, 140, 136, 142, 139, 137,
            187, 154, 151, 149, 148, 157, 159, 143, 124, 141, 114, 136,
            110, 129, 145, 132, 125, 149, 146, 138, 151, 147, 154, 147,
            158, 156, 156, 128, 151, 138, 193, 131, 127, 129, 120, 159,
            147, 159, 156, 143, 149, 160, 126, 136, 150, 136, 151, 140,
            145, 140, 134, 140, 138, 144, 140, 140]

no_concebido=[159, 136, 149, 156, 191, 169, 194, 182, 163, 152, 145, 176,
              122, 141, 172, 162, 165, 184, 239, 178, 178, 164, 185, 154,
              164, 140, 207, 214, 165, 183, 218, 142, 161, 168, 181, 162,
              166, 150, 205, 163, 166, 176,]

conjunto=[]
indicador=[]

for i in range(len(concebido)):
    conjunto.append(1)
    indicador.append(concebido[i])


for i in range(len(no_concebido)):
    conjunto.append(0)
    indicador.append(no_concebido[i])




lim_max=np.max([np.max(concebido),np.max(no_concebido)])
lim_min=np.min([np.min(concebido),np.min(no_concebido)])




def curva_roc(conjunto,indicador):

    S=[]
    E=[]

    for i in indicador:
        VP=[]
        FP=[]
        VN=[]
        FN=[]
        for k in range(len(conjunto)):
            if indicador[k]<i:
                if conjunto[k]==0:
                    VP.append(k)
                else:
                    FP.append(k)
            else:
                if conjunto[k]==1:
                    VN.append(k)
                else:
                    FN.append(k)
        S.append(len(VP)/float((len(VP)+len(FN)+0.0001)))
        E.append(len(VN)/float((len(FP)+len(VN)+0.0001)))

    Uno_menos_E=np.ones(len(indicador))-E
    B={}

    for i in range(len(indicador)):
        if S[i]<Uno_menos_E[i]:
            S[i]=1-S[i]
            Uno_menos_E[i]=1-Uno_menos_E[i]
        B[Uno_menos_E[i]]=S[i]
    B1=[]
    B2=[]
    B1=sorted(B.keys())
    for i in range(len(B)):
        B2.append(B[B1[i]])
    integral=0

    for i in range(len(B))[1:]:
        a=abs((B1[i]-B1[i-1])*((B2[i-1])+(B2[i]-B2[i-1])/2))
        integral=integral+a

    V1=np.array(B1)
    V2=np.array(B2)
    a1=V1*V1
    a2=np.sqrt((V2-np.ones(len(V2)))*(V2-np.ones(len(V2))))
    distancias=np.array(np.sqrt(a1+a2))
    m=min(distancias)

    for i in range(len(B)):
        if distancias[i]==m:
            punto_nivel=[B1[i],B2[i]]

    x=sorted(indicador)
    for j in range (len(indicador)):
        if punto_nivel==[Uno_menos_E[j],S[j]]:
            nivel=x[j]

    plt.plot(B1,B2,label='Curva ROC')
    plt.plot(S,S)
    plt.annotate('AUC='+str(integral),(0.6,0.2),(0.6,0.2))
    plt.annotate(u'Punto optimo', xytext=(0.5,0.4), xy=(punto_nivel),
                 arrowprops=dict(facecolor='black', shrink=0.05, width=0.1))
    plt.annotate(u'de clasificacion',xytext=(0.5,0.35), xy=(0.5,0.35))
    plt.annotate(u'Nivel optimo='+str(nivel),xytext=(0.5,0.30), xy=(0.5,0.30))
    plt.legend(loc=4)
    plt.xlabel(u'1-especificidad')
    plt.ylabel('sensibilidad')
    plt.savefig('ROCesperma.png')

def histograma():

    plt.figure()
    plt.hist(concebido,bins=50,label='concebido')
    plt.hist(no_concebido,bins=50,label='no concebido')
    plt.axvline(x=162, ymin=0.0, ymax = 12, linewidth=2, color='r',label=u'corte optimo')
    plt.legend()
    plt.savefig('histogramaROCesperma.png')


curva_roc(conjunto,indicador)

histograma()