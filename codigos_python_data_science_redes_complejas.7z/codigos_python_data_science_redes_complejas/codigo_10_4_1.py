# -*- coding: utf-8 -*-

import numpy as np
import graph_tool.all as gt
from matplotlib import pyplot as plt


def riesgo(g,v):

    W=np.zeros((g.num_vertices(),g.num_vertices()))

    for e in g.edges():
        suma_pesos = 0.0
        for e2 in g.edges():
            if(e2.target()==e.target()):
                suma_pesos+=peso[e2]

        suma_pesos+=0.0001
        W[g.vertex_index[e.source()],g.vertex_index[e.target()]]=peso[e]/float(suma_pesos)

    A=np.zeros((g.num_vertices(),g.num_vertices()))

    for i in range(g.num_vertices()):
        for j in range(g.num_vertices()):
            A[i,j]=W[i,j]

    I=np.identity(g.num_vertices())
    T=np.dot(A,np.linalg.inv(I-A))

    R = np.dot(v,T)
    print "R sin norma",R

    R_avg = R / (np.dot(np.full(T.shape[1],1),T)+0.0000001)
    print (np.dot(np.full(T.shape[1],1),T)+0.0000001)

    print "R ponderado",R_avg

    plt.figure()

    for i in range(len(R_avg)):
        plt.scatter(i,R_avg[i])
        plt.scatter(i,v[i])

    plt.plot(v,label='riesgo primario')
    plt.plot(R_avg,label='riesgo repercutido')
    plt.title('Riesgo repercutido y riesgo primario')

    plt.legend(loc=8,ncol=2)
    plt.savefig('ejemplo-riesgo-repercutido1.png',dpi=400)