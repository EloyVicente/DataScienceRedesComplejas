# -*- coding: utf-8 -*-

import Queue

def recorrido_profundidad_arbol(G,s):

    A=[]
    Q=Queue.LifoQueue()
    Q.put(s)

    while not Q.empty():
        u=Q.get()
        print u
        A.append(u)
        sucesores=list(G.sucesores(u))
        sucesores.reverse()
        for v in sucesores:
            Q.put(v)

    return A