# -*- coding: utf-8 -*-


import numpy as np
import pylab as pl
import matplotlib.pyplot as plt
import math
from math import *
from fractions import Fraction

X=np.loadtxt('distancias_ciudades.txt')
Nombres=['Madrid', 'Barcelona', 'Valencia', 'Sevilla', u'San_Seastian',
         u'La_Coruna']
X=X*X
N=len(X)
n=float(Fraction(1,N))

D=np.zeros((N, N))
UNO=np.ones((1,N))

B=np.dot(np.identity(N)-
         n*np.dot(UNO.transpose(),UNO),
         (-0.5)*X,np.identity(N)-n*np.dot(UNO.transpose(),
                                 UNO))


lambd , vec = np.linalg.eig(B)

a=sorted(lambd,reverse = True)

r=(a[0]+a[1])/sum(lambd)

############################## Rotacion  y Proyeccion ###########
DELTA=np.zeros((N,N))
DELTA[0,0]=sqrt(a[0])
DELTA[1,1]=sqrt(a[1])

X_t=np.dot(vec,DELTA)

A_=X_t[:,0]
B_=X_t[:,1]

##############################Visualizacion######################
target_name=Nombres
plt.figure('scatter') # Crea una ventana titulada 'scatter'

plt.figure('scatter')

plt.scatter(A_,B_)

for i in range(N):
    plt.text(A_[i], B_[i]+25, target_name[i], fontsize = 10, horizontalalignment='center',

    verticalalignment='center')

plt.legend(loc = 1)

pl.title('Mapa de ciudades a partir de matriz de distancias')
plt.show()