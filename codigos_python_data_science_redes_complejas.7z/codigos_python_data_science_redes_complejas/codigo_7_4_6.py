# -*- coding: utf-8 -*-

import networkx as nx
import numpy as np
import matplotlib.pyplot as plt


def grafo_exponencial(n):

    g=nx.Graph()
    v0=g.add_node(0)

    for i in range(1,n):
        a=np.random.randint(i)
        vi=g.add_node(i)
        g.add_edge(i,a)
    plt.figure()
    pos=nx.spectral_layout(g)
    nx.draw(g,node_size=40)
    plt.title('Grafo exponencial de '+str(n)+' nodos')
    plt.savefig('grafo_exponencial.png',dpi=400)
    grados=[]

    for v in g.nodes():
        grados.append(g.degree(v))
    plt.figure()
    plt.hist(grados)
    plt.title(u'Distribucion del grado nodal de un \n''grafo exponencial de '+str(n)+' nodos')
    plt.xlabel('Grado nodal')
    plt.ylabel(u'Numero de nodos')
    plt.savefig('distribucion_grafo_exponencial.png',dpi=400)


    return g

grafo_exponencial(1000)