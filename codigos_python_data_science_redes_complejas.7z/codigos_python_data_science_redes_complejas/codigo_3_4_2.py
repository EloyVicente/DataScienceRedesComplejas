# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import numpy as np
from sklearn import datasets , manifold

iris = datasets.load_iris()
X = iris.data
X_centrada=X-X.mean(0)
n=len(X_centrada)

D=np.zeros((n,n))
Q=np.zeros((n,n))

for i in range(n):
    for j in range(n):
        D[i,j]=np.dot(X_centrada[i]-X_centrada[j],X_centrada[i]-X_centrada[j])

for i in range(n):
    for j in range(n):
        Q[i,j]=0.5*(-D[i,j]+(1.0/n)*np.sum(D[i])+(1.0/n)*np.sum(D.transpose()[j])-(1.0/(n**2))*np.sum(D))

lambd , vec = np.linalg.eig(Q)

a=lambd[0]/(sum(lambd))
b=lambd[1]/(sum(lambd))
v1=vec[:,0]
v2=vec[:,1]

Diagonal=np.zeros((n,n))
Diagonal[0,0]=np.sqrt(lambd[0])
Diagonal[1,1]=np.sqrt(lambd[1])

proyeccion=np.dot(vec,Diagonal)
plt.scatter(proyeccion[:,0],proyeccion[:,1])