# -*- coding: utf-8 -*-


import numpy as np
from matplotlib import pyplot as plt
import csv
from sklearn.decomposition import FactorAnalysis

def analisis_factorial(ruta,matriz):
    
    factor = FactorAnalysis(n_components=7, random_state=10)
    factor.fit(matriz)
    return factor.components_

ruta='ejemplo-estudiantes.csv'
filas=list(csv.reader(open(ruta,'rb'), delimiter=';'))

n=len(filas)-1
p=len(filas[2])-1

matriz=np.zeros((n,p))

for i in range(n+1):
        for j in range(p+1):
            filas[i][j]=filas[i][j].replace(',','.')
for i in range(n):
        for j in range(p):
            matriz[i,j]=float(filas[i+1][j+1])

listado_asignaturas=[u'Matematicas',u'Fisicas','Historia',
                     'Literatura','Idiomas',u'Ed. Fisica',
                     u'Ed. Plastica']
factores=analisis_factorial(ruta,matriz)
listado_factores=['Ciencias','Letras',u'Hab. fis. y art.']
for i in range(7):
    R=factores.transpose()[i]
    plt.figure()
    plt.bar(np.arange(3), R[0:3])
    plt.title('Asignatura de '+str(listado_asignaturas[i]))
    plt.xticks(np.arange(3), listado_factores, rotation = 45)
    plt.savefig('ejemplofa'+str(listado_asignaturas[i])+'.png')

for i in range(3):
    R=factores[i]
    plt.figure()
    plt.bar(np.arange(7), R)
    plt.title('Factor de '+str(listado_factores[i]))
    plt.xticks(np.arange(7), listado_asignaturas, rotation = 45)
    plt.savefig('ejemplofa'+str(listado_factores[i])+'.png')
    
