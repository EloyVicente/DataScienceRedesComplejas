# -*- coding: utf-8 -*-

import numpy as np
import sklearn
from sklearn import datasets
from numpy.linalg import eig

iris = datasets.load_iris()
X_r = iris.data
Y = iris.target
X=X_r-X_r.mean(0)

S=np.dot(X.transpose(),X)/149
inversa=np.linalg.inv(S)
gamma=np.zeros((4,4))

for i in range(4):
    gamma[i,i]=1.0/inversa[i,i]

Q=S-gamma
G=np.zeros((4,4))
val1,vec1=eig(Q)
vec=vec1.transpose()

idx = val1.argsort()[::-1]
val= val1[idx]
vec = vec[idx].transpose()

for i in range(2):
    G[i,i]=np.sqrt(val[i])

DELTA_0=np.dot(G,vec.transpose())
dif=1

while dif>0.0001:

    diagonal=np.diag(S-np.dot(DELTA_0.transpose(),DELTA_0))

    for i in range(4):
        gamma[i,i]=diagonal[i]

    Q=S-gamma
    
    G=np.zeros((4,4))
    val1,vec1=eig(Q)
    vec=vec1.transpose()

    idx = val1.argsort()[::-1]
    val= val1[idx]
    vec = vec[idx].transpose()

    for i in range(1):
        G[i,i]=np.sqrt(val[i])

    DELTA=np.dot(G,vec.transpose())

    dif=np.linalg.norm(DELTA_0-DELTA)
    DELTA_0=DELTA
    print dif
    
