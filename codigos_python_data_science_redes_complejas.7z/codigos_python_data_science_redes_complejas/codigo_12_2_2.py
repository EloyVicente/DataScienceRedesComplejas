# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-


import unicodedata
import nltk
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

def posiciones(subcadena,cadena):

    k=cadena.find(subcadena)
    pos=[k]

    while cadena[pos[-1]+len(subcadena):].find(subcadena)>-1:
        k=pos[-1]+cadena[pos[-1]+len(subcadena):].find(subcadena)+len(subcadena)
        pos.append(k)

    return pos

def lista_frecuencias(texto,umbral,longitud_minima):


   f=file(texto)
   txt=f.read()
   txt=unicode(txt, "latin2")
   txt=unicodedata.normalize('NFD', txt).encode('ascii','ignore')
   global txt2

   f.close()
   txt=txt.lower()
   txt=txt.replace('\n',' ')

   char_ok=[32]+range(97,122)
   for j in range(256):
       if j not in char_ok:
           txt=txt.replace(chr(j),'')
   txt2=txt
   txt=txt.split(' ')
   L=nltk.FreqDist(txt)

   frecuencia={}
   for i in L.keys():
       if L[i]>umbral*len(txt)/100.0 and len(i)>longitud_minima:
           frecuencia[i]=L[i]

   return frecuencia,txt2

def red_palabras(texto,umbral,longitud_minima,descartes=[]):

    frecuencia,txt2=lista_frecuencias(texto,umbral,longitud_minima)

    diccionario_posiciones={}
    for i in frecuencia.keys():
        diccionario_posiciones[i]=posiciones(i,txt2)

    distancias_totales={}
    for i in frecuencia.keys():
        for j in frecuencia.keys():
            distancias_totales[(i,j)]=[]
            for k in diccionario_posiciones[i]:
                for r in diccionario_posiciones[j]:
                    distancias_totales[(i,j)].append(np.abs(k-r))
            distancias_totales[(i,j)].sort()


    g=nx.Graph()
    etiquetas={}
    area={}
    nodesize=[]
    for i in frecuencia.keys():
        if i not in descartes:
            u=g.add_node(i)
            etiquetas[i]=i
            area[u]=frecuencia[i]
            nodesize.append(area[u]*1000)

    global pesos_palabras
    pesos_palabras={}
    edgesize=[]
    for i in frecuencia.keys():
        for j in frecuencia.keys():
            if i!=j and i not in descartes and j not in descartes:

                pesos_palabras[(i,j)]=10000.0/np.sum(distancias_totales[(i,j)][0:10])/10.0
                if pesos_palabras[(i,j)]>0.5:

                    g.add_edge(i,j,{'peso':pesos_palabras[(i,j)]})
                    edgesize.append(10*pesos_palabras[(i,j)])

    pos=nx.spring_layout(g)
    #nx.draw_networkx_nodes(g,pos,node_size=2000)
    plt.figure(figsize=(10,10))
    nx.draw_networkx_nodes(g,pos,node_size=nodesize,node_color='w',alpha=0.4)
    nx.draw_networkx_labels(g,pos,labels=etiquetas,font_size=15)
    nx.draw_networkx_edges(g,pos,alpha=0.4,node_size=0,width=edgesize,edge_color='k')
    plt.axis('off')
    plt.savefig('red_palabras.png',dpi=400)

    return pesos_palabras,g



texto='texto.txt'
L=red_palabras(texto,umbral=0.2,longitud_minima=4,descartes=['entre','puede','sobre','estas'])

