# -*- coding: utf-8 -*-

carpeta1=glob.glob('ruta1/blues/*.*')
carpeta2=glob.glob('ruta2/metal/*.*')

matriz=[]

for i in carpeta1:
    sample_rate,Y=scipy.io.wavfile.read(str(i))
    ceps,mspec,spec=mfcc(Y)
    z=np.mean(ceps[int(len(ceps)*0.1):int(len(ceps)*0.9)],axis=0)
    matriz.append(z)

for i in carpeta2:
    sample_rate,Y=scipy.io.wavfile.read(str(i))
    ceps,mspec,spec=mfcc(Y)
    z=np.mean(ceps[int(len(ceps)*0.1):int(len(ceps)*0.9)],axis=0)
    matriz.append(z)

X=np.array(matriz)
mu = X.mean()
X = X - mu

def pca(X):

    C = np.dot(X,X.T)
    [autovalores,autovectores] = np.linalg.eigh(C)

    autovalores = autovalores[0:3].copy()
    autovectores = autovectores.T[:3,0:13]

    proyeccion=np.dot(X, autovectores.T)
    fig=plt.figure()
    ax = fig.gca(projection='3d')
    ax.scatter(proyeccion[0,0],proyeccion[0,1],proyeccion[0,2],c='r',label='Blues')
    ax.scatter(proyeccion[100,0],proyeccion[34,1],proyeccion[100,2],c='b',label='Metal')
    for i in range(1,len(proyeccion)):

        if i<100:
            ax.scatter(proyeccion[i,0],proyeccion[i,1],proyeccion[i,2],c='r')
        else:
            ax.scatter(proyeccion[i,0],proyeccion[i,1],proyeccion[i,2],c='b')

    plt.legend(loc=3)
    plt.title(u'Proy. sobre las tres primeros componentes principales de \n'
			u' los 13 coeficientes de MEL de melodias blues y metal')
    plt.savefig('PCA_generos_musicales.png',dpi=400)
    plt.show()

    return proyeccion


def discriminante(X):

    clases=[0 for i in range(100)]+[1 for i in range(100)]
    clf = lda.LDA(n_components=1)#svm.SVC()#
    global X_r2
    X_r2 =clf.fit(X, clases).transform(X)
    scores = cross_validation.cross_val_score(clf, X, np.array(clases), cv=10)
    color_= {}
    for i in range(len(clases)):
        if clases[i]==0:
            color_[i]='r'
            ejemplo_blues=i
            color_[ejemplo_blues]='r'
        else:
            ejemplo_metal=i
            color_[ejemplo_metal]='b'
            color_[i]='b'
    plt.figure()
    plt.scatter(X_r2[ejemplo_metal, 0], X_r2[ejemplo_metal, 0]+2*np.random.rand(),
			c=color_[ejemplo_metal],label='Metal')
    plt.scatter(X_r2[ejemplo_blues, 0], X_r2[ejemplo_blues, 0]+2*np.random.rand(),
			c=color_[ejemplo_blues],label='Blues')
    for i in range(len(X)):
        plt.scatter(X_r2[i, 0], X_r2[i, 0]+2*np.random.rand(),color=color_[i],edgecolors='k')
    plt.title(u'Direccion de maxima discriminacion (LDA) \n' 
				u'para melodias blues y melodias metal')
    plt.legend(loc=2)
    plt.savefig('lda_generos_musicales.png',dpi=400)

