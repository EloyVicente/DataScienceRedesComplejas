# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import numpy as np
from sklearn import linear_model

X=np.array([[0.0],[5.0],[10.0],[15.0],[20.0],[25.0]])
Y=np.array([-0.94,-0.66,-0.37,-0.350,0.12,0.44])

regr = linear_model.LinearRegression()
regr.fit(X, Y)

pendiente=regr.coef_[0]
ordenada=regr.intercept_

print regr.coef_
print regr.intercept_

plt.figure()
x=np.linspace(0,25,100)
y1=pendiente*x+ordenada
plt.scatter(X,Y)
plt.plot(x,y1)
plt.ylabel('Logit')
plt.xlabel(u'Numero de cigarrillos')
plt.savefig('recta-regresion.png')
plt.title(u'Recta de regresion cantidad de tabaco vs enfermeda')

fig=plt.figure()
x2=np.linspace(-100,200,1000)
y2=1/(1+np.exp(-pendiente*x2-ordenada))
plt.ylabel('Probabilidad de padecer la enfermedad')
plt.xlabel(u'Numero de cigarrillos')
#plt.scatter(X,Y)
plt.plot(x2,y2)

plt.savefig('logit.png')
