# -*- coding: utf-8 -*-

from matplotlib import pyplot as plt
import numpy as np
#from sklearn.cluster import KMeans
import scipy
from scipy import random
from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.datasets.samples_generator import make_blobs
from sklearn.preprocessing import StandardScaler
n=1000
m=1000

a1 = scipy.zeros([n])
b1 = scipy.zeros([n])

a2 = scipy.zeros([n])
b2 = scipy.zeros([m])

X=scipy.zeros([n+m,2])

for i in range(n):
    a1[i] = np.random.normal(0.5, 0.05)
    b1[i] =np.random.normal(0.5, 0.05)
    X[i,0]=a1[i]
    X[i,1]=b1[i]

for i in range(m):
    a2[i] = np.random.rand()
    b2[i] =0.5*pow(a2[i],6)+np.random.normal(0.2,0.02)
    X[i+n,0]=a2[i]
    X[i+n,1]=b2[i]

db = DBSCAN(eps=0.03, min_samples=10).fit(X)
core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
core_samples_mask[db.core_sample_indices_] = True
labels = db.labels_

n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)

##############################################################################

fig=plt.figure()
plt.scatter(a1,b1)
plt.scatter(a2,b2)
plt.show()

unique_labels = set(labels)
colors = plt.cm.Spectral(np.linspace(0, 1, len(unique_labels)))
for k, col in zip(unique_labels, colors):
    if k == -1:

        col = 'k'

    class_member_mask = (labels == k)

    xy = X[class_member_mask & core_samples_mask]
    plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=col,
             markeredgecolor='k', markersize=14)

    xy = X[class_member_mask & ~core_samples_mask]
    plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=col,
             markeredgecolor='k', markersize=6)

plt.title(u'Numero de clusters estimados: %d' % n_clusters_)
plt.show()