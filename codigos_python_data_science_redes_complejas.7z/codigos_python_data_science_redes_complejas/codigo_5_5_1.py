# -*- coding: utf-8 -*-
import numpy as np
from matplotlib import pyplot as plt
from sklearn import svm

N=100
sd=1
x1=np.random.normal(2,sd,N)
y1=np.random.normal(2,sd,N)
z1=np.zeros(N)

x2=np.random.normal(5,sd,N)
y2=np.random.normal(5,sd,N)
z2=np.ones(N)
plt.xlim([-2, 8])
plt.ylim([-2, 10])
plt.scatter(x1,y1,c='b',label='Clase 0')
plt.scatter(x2,y2,c='r',label='Clase 1')
plt.legend(loc=2)
plt.title('Puntos para a clasificar')
plt.savefig('nubesclasificacionsvm.png')
color=[]
for i in range(N):
    color.append('b')

for i in range(N):
    color.append('r')

def maquinas_vectores(x,y,metodo='lineal'):

    clf = svm.SVC()
    X=[[x1[i],y1[i]] for i in range(N)]+[[x2[i],y2[i]] for i in range(N)]
    X=np.array(X)
    target=list(z1)+list(z2)

    h=0.001

    #C=0.2
    if metodo=='lineal':
        svc=svm.LinearSVC().fit(X,target)
    elif metodo=='cuadratico':
        svc=svm.NuSVC().fit(X,target)
    elif metodo=='polinomial':
        svc=svm.SVC(kernel='poly',degree=3).fit(X,target)
    #print svc

    x_min, x_max=-2,8
    y_min, y_max=-2,10
    xx,yy=np.meshgrid(np.arange(x_min,x_max,h),np.arange(y_min,y_max,h))
    #3print xx
    Z=svc.predict(np.c_[xx.ravel(),yy.ravel()])
    #print Z

    Z=Z.reshape(xx.shape)

    plt.contourf(xx,yy,Z,cmap=plt.cm.Paired,alpha=0.3)
    plt.scatter(X[:,0],X[:,1],c=color)
    plt.scatter(x,y,marker='+',linewidth='20',c='g')
    plt.title(u'Clasificacion por  maquinas de vectores soporte')

    plt.savefig('clasificacionsvm'+metodo+'.png')
    prediccion=svc.predict([x,y])[0]
    print ('La clase del elemento'+str([x,y])+'es '+str(prediccion))

    return prediccion

maquinas_vectores(x=2,y=2,metodo='lineal')