# -*- coding: utf-8 -*-

def shingles(texto, k):
    kshingles=[]
    for i in xrange(len(texto)-(k-1)):
        kshingles.append(texto[i:i+k])
    return kshingles

def jaccard(texto1,texto2):
    texto1=set(texto1)
    texto2=set(texto2)
    interseccion=float(len(texto1.intersection(texto2)))
    union=float(len(texto1.union(texto2)))
    return interseccion/union


L=shingles('Serafin, corre mas el galgo que el mastin', 3)
G=shingles('Mas si el camino es largo', 3)
H=shingles('Mas corre el mastin que el galgo', 3)

print(jaccard(L,G))
print(jaccard(L,H))
print(jaccard(H,G))
