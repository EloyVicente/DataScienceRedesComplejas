# -*- coding: utf-8 -*-
import scipy
import scipy.cluster.hierarchy as sch
import matplotlib.pyplot as plt

# Generamos 15 puntos aleatorios en el plano y su matriz de distancias
x = scipy.rand(15)
y = scipy.rand(15)
D = scipy.zeros([15,15])
for i in range(15):
    for j in range(15):
        D[i,j] = abs(x[i] - x[j])+ abs(y[i] - y[j])


plt.close ()
fig = plt.figure(u"Clustering jerarquico")

# Dibujamos la nube de puntos
plt.subplot(121)
plt.scatter(x,y)
a=[]
for i in range(15):
    a.append(str(i))

    plt.text(x[i],y[i]+0.025, a[i], fontsize = 10,
horizontalalignment='center', verticalalignment='center')

plt.title(u'Nube de puntos')

plt.subplot(122)

# Dibujamos el dendrograma.

Y = sch.linkage(D, method='centroid')
Z = sch.dendrogram(Y)
plt.title(u'Dedrograma sobre \n' 'la nube de puntos')

fig.show()
fig.savefig("clustering1.png")
