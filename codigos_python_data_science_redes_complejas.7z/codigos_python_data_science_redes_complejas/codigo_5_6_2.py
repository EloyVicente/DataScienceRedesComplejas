# -*- coding: utf-8 -*-

import numpy as np
from matplotlib import pyplot as plt
from sklearn import svm

N=100
sd=1
x1=np.random.normal(2,sd,N)
y1=np.random.normal(2,sd,N)
z1=np.zeros(N)

x2=np.random.normal(5,sd,N)
y2=np.random.normal(5,sd,N)
z2=np.ones(N)
plt.xlim([-2, 8])
plt.ylim([-2, 10])
plt.scatter(x1,y1,c='b',label='Clase 0')
plt.scatter(x2,y2,c='r',label='Clase 1')
plt.legend(loc=2)
plt.title('Puntos para a clasificar')
plt.savefig('nubesclasificacionknn.png')
color=[]
for i in range(N):
    color.append('b')

for i in range(N):
    color.append('r')

def knn(k,x,y):

    plt.xlim([-2, 8])
    plt.ylim([-2, 10])
    plt.scatter(x1,y1,c='b',label='Clase 0')
    plt.scatter(x2,y2,c='r', label='Clase 1')
    plt.scatter(x,y,marker='+',linewidth='20',c='g')

    plt.legend()
    distancias1=[]
    distancias2=[]
    for i in range(N):
        distancias1.append(np.sqrt((x-x1[i])**2+(y-y1[i])**2))
        distancias2.append(np.sqrt((x-x2[i])**2+(y-y2[i])**2))

    distancias=distancias1+distancias2
    distancias.sort()

    k_minimos=[distancias[i] for i in range(k)]

    clases_k_minimos=[]
    for i in k_minimos:
        if i in distancias1:
            clases_k_minimos.append(0)
        else:
            clases_k_minimos.append(1)

    if np.sum(clases_k_minimos)>k/2.0:
        prediccion=1
    else:
        prediccion=0

    print clases_k_minimos
    print ('Clase predicha: '+str(prediccion))
    plt.title('Puntos para a clasificar. Clase '+str(prediccion))
    plt.savefig('clasificacionknn'+str(x)+str(y)+'.png')
    return prediccion
    