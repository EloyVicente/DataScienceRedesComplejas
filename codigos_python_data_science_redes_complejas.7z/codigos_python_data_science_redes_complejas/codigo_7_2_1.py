# -*- coding: utf-8 -*-

import networkx as nx
import matplotlib.pyplot as plt

usuarios={}

usuarios[0]={'nombre':'Manuel', 'apellidos': 'Fernandez Garcia','edad':35,'profesion':'profesor'}
usuarios[1]={'nombre':'Maria', 'apellidos':'Rodriguez lopez', 'edad':38, 'profesion':'medico'}
usuarios[2]={'nombre':'Carlos','apellidos':'Fernandez Rodriguez','edad':16,'profesion':'estudiante'}
usuarios[3]={'nombre':'Concha', 'apellidos':'Montero Perez','edad':33,'profesion':'profesor'}
usuarios[4]={'nombre':'Antonio', 'apellidos':'Sanchez Jimenez', 'edad':36, 'profesion':'administrativo'}
usuarios[5]={'nombre':'Mario','apellidos':'Sanchez Montero','edad':16,'profesion':'estudiante'}

g=nx.Graph()

for i in usuarios.keys():
    g.add_node(i,usuarios[i])

g.add_edge(0,1,{'tipo':'familiar'})
g.add_edge(0,2,{'tipo':'familiar'})
g.add_edge(1,2,{'tipo':'familiar'})
g.add_edge(2,5,{'tipo':'amigos'})
g.add_edge(5,3,{'tipo':'familiar'})
g.add_edge(3,4,{'tipo':'familiar'})
g.add_edge(4,5,{'tipo':'familiar'})
g.add_edge(0,3,{'tipo':'colegas'})

etiquetas_nodos={}
color_nodos={}
for i in usuarios.keys():
    etiquetas_nodos[i]=usuarios[i]['nombre']
    if i in [2,5]:
        color_nodos[i]='g'
    else:
        color_nodos[i]='r'

familiares=[]
colegas=[]
amigos=[]
for e in g.edges():
    if g[e[0]][e[1]]['tipo']=='familiar':
        familiares.append(e)
    elif g[e[0]][e[1]]['tipo']=='colegas':
        colegas.append(e)
    else:
        amigos.append(e)

pos=nx.spring_layout(g)
nx.draw_networkx_nodes(g,pos,node_color=color_nodos.values(),node_size=900)
nx.draw_networkx_labels(g,pos,labels=etiquetas_nodos,font_size=8)
nx.draw_networkx_edges(g,pos,edgelist=familiares,edge_color='r',width=2)
nx.draw_networkx_edges(g,pos,edgelist=amigos,edge_color='b',width=2,style='dashed')
nx.draw_networkx_edges(g,pos,edgelist=colegas,edge_color='g',width=2,style='dashed')

plt.axis('off')
plt.savefig("red_social_1.png")
plt.show()