# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt

n=100
x={}
for i in range(n):
    x[i]=np.random.rand(10000)

y=x[0]

for i in range(1,n):
    y=y+x[i]
plt.figure()
plt.hist(x[0])
plt.title(u'Distribucion uniforme en [0,1]')
plt.savefig('tcl1.png',dpi=400)
plt.figure()
plt.hist(y)
plt.title('Suma de 100 distribuciones \n'' uniformes en [0,1]')

plt.savefig('tcl2.png',dpi=400)

