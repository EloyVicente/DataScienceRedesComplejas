# -*- coding: utf-8 -*-

def probabilidad_amistad(g):
    
    global comunes
    comunes={}
    probabilidad={}
    n=len(g.nodes())
    arcos=float(len(g.edges()))

    grados=[]
    for v in g.nodes():
        grados.append(g.degree(v))

    for i in range(int(np.mean(grados))):
        comunes[i]=[0,0]

    parejas_visitadas=[]
    for v in g.nodes():
        vecinos_v=set(g.neighbors(v))
        for w in g.nodes():
            if w!=v and (v,w) not in parejas_visitadas and (w,v) not in parejas_visitadas:
                vecinos_w=set(g.neighbors(w))
                amigos_comunes=len(vecinos_v.intersection(vecinos_w))
                if v in g.neighbors(w):
                    comunes [amigos_comunes][0]+=1

                else:
                    comunes[amigos_comunes][1]+=1
                parejas_visitadas.append((v,w))

    for i in comunes.keys():
        if comunes[i][0]+comunes[i][1]!=0:
            probabilidad[i]=float(comunes[i][0])/(comunes[i][0]+comunes[i][1])
        else:
            probabilidad[i]=1

    plt.plot(probabilidad.values())

    plt.xlabel(u'Numero de amigos comunes')
    plt.ylabel(u'Probabilidad de ser amigos')
    plt.title('Probabilidad de ser amigos vs amigos comunes \n''Red de Watts-Strogatz')

    plt.savefig('probabilidad_amistad_watt_strogatz.png',dpi=400)

    return comunes, probabilidad