# -*- coding: utf-8 -*-

import numpy as np
import graph_tool.all as gt
import numpy as np
from matplotlib import pyplot as plt
import matplotlib
import pylab
from sklearn import manifold
import scipy.cluster.hierarchy as sch
from sklearn.cluster import DBSCAN
from mpl_toolkits.mplot3d import Axes3D
from sklearn.cluster import KMeans

g=gt.collection.data["polbooks"]
grafpos=gt.sfdp_layout(g)
n=len(set(g.vertices()))
A=np.zeros((n,n))
for v in g.vertices():
    for w in g.vertices():
        A[v,w]=gt.shortest_distance(g,v,w)

def mds():

    seed=np.random.RandomState(seed=1)
    nmds=manifold.MDS(n_components=3, max_iter=3000000, metric='True', eps=1e-9,
                      random_state=seed,
                     dissimilarity="precomputed", n_jobs=1, n_init=1)
    npos=nmds.fit_transform(A)
    print npos
    fig=plt.figure()
    ax=plt.axes(projection='3d')
    for i in range(len(npos)):
        ax.scatter(npos[i][0],npos[i][1],npos[i][2])

    plt.title('Escalado multidimensional 3D sobre los nodos del grafo polbooks')
    plt.savefig('mdsgrafo1')

    return npos

def kmedias(npos,k=3):

    kmeans=KMeans(init='k-means++', n_clusters=k, n_init=5)

    fig=plt.figure()
    plt.clf()
    ax=plt.axes(projection='3d')#Axes3D(fig)#,rect=[0,0,1,1], elev=48,azim=134)
    plt.cla()
    kmeans.fit(npos)
    labels=kmeans.labels_
    ax.scatter(npos[:,0],npos[:,1],npos[:,2], c=labels.astype(np.float))
    plt.title('K-medias sobre nube de puntos 3D')
    plt.savefig('kmediasgrafo')

    return labels

def comunidades(g):

    npos=mds()
    labels=kmedias(npos,k=3)

    color=g.new_vertex_property("vector<float>")
    g.vertex_properties["color"]=color

    for v in g.vertices():
        if labels[g.vertex_index[v]]==0:
            color[v]=[0,1,0]
        elif labels[g.vertex_index[v]]==1:
            color[v]=[1,0,0]
        else:
            color[v]=[0,0,1]

    gt.graph_draw(g,vertex_font_size=9,vertex_size=10, pos=grafpos,
                          output_size=(500,500),
                             output="polbooks5.png",fmt="png")


    gt.graph_draw(g,vertex_font_size=9,vertex_size=10, vertex_fill_color=color, pos=grafpos,
                          output_size=(500,500),
                             output="polbooks6.png",fmt="png")