# -*- coding: utf-8 -*-

import networkx as nx
import numpy as np
import matplotlib.pyplot as plt


def grafo_barabasi_albert(r):

    g=nx.Graph()
    v0=g.add_node(0)
    v1=g.add_node(1)
    g.add_edge(0,1)
    for i in range(2,r):
        g.add_node(i)
        cadena_nodos=[]
        for j in g.nodes():
            cadena_nodos=cadena_nodos+[j for k in range(g.degree(j))]
        n=np.random.randint(len(cadena_nodos))
        g.add_edge(i,cadena_nodos[n])

    nx.draw(g,node_size=40)
    plt.title('Grafo Barabasi-Albert de '+str(r)+' nodos')
    plt.savefig('grafo_barabasi.png',dpi=400)

    grados=[]
    for v in g.nodes():
        grados.append(g.degree(v))

    plt.figure()
    plt.hist(grados)
    plt.title(u'Distribucion del grado nodal de un \n''grafo de Barabasi-Albert de '+str(r)+' nodos')
    plt.xlabel('Grado nodal')
    plt.ylabel(u'Numero de nodos')
    plt.savefig('distribucion_barabasi.png',dpi=400)

grafo_barabasi_albert(500)