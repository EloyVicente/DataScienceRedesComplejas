# -*- coding: utf-8 -*-

import networkx as nx
import numpy as np
import matplotlib.pyplot as plt


def grafo_watts_strogatz(n, k, alpha,dibujo=True):

    if k<n:
        g = nx.Graph()
        nodos = range(n)

        for j in range(1, 2*k // 2+1):
            targets = nodos[j:] + nodos[0:j]
            g.add_edges_from(zip(nodos,targets))

        for j in range(1, 2*k // 2+1):
            targets = nodos[j:] + nodos[0:j]
            for u,v in zip(nodos,targets):
                if np.random.random() < alpha:
                    w = np.random.choice(nodos)

                    while w == u or g.has_edge(u, w):
                        w = np.random.choice(nodos)
                        if g.degree(u) >= n-1:
                            break
                    else:
                        g.remove_edge(u,v)
                        g.add_edge(u,w)
        if dibujo==True:
            plt.figure()
            nx.draw(g,node_size=40)
            plt.title('Grafo de Watts-Strogatz de '+str(n)+' nodos')
            plt.savefig('grafo_watts.png',dpi=400)
    
            grados=[]
            for v in g.nodes():
                grados.append(g.degree(v))
                
            plt.figure()
            plt.hist(grados)
            plt.title(u'Distribucion del grado nodal de un \n''grafo de Watts-Strogatz de '+str(n)+' nodos')
            plt.xlabel('Grado nodal')
            plt.ylabel(u'Numero de nodos')
            plt.show()
            plt.savefig('distribucion_wats_strogatz.png',dpi=400)
        
        return g

    else:
        print("Elegir un valor de k<n")
        
grafo_watts_strogatz(n=50, k=2, alpha=0.1,dibujo=True)