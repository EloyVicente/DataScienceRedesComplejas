# -*- coding: utf-8 -*-
import Queue
import numpy as np
import sys

class grafo:

    def __init__(self,V,E,pesos={},dirigido=bool,ponderado=bool):

        self.dirigido=dirigido
        self.V=V
        self.pesos=pesos
        self.ponderado=ponderado

        if dirigido:
            self.E=E
        else:
            self.E=E+[(v,u) for (u,v) in E]

        if ponderado==False:

            for i in self.E:
                self.pesos[i]=1.0
        else:
            print('Ha generao un grafo ponderado. No olvide indicar los pesos de los arcos')


    def sucesores(self, u):


        sucesores=[]
        if self.dirigido:
            for (v,w) in E:
                if v==u:
                    sucesores.append(w)
        else:
            for (v,w) in E:
                if v==u:
                    sucesores.append(w)
                elif w==u:
                    sucesores.append(v)


        return sucesores


    def predecesores(self, v):

        predecesores=[]
        if self.dirigido:
            for (u,w) in E:
                if w==v:
                    predecesores.append(u)
        else:
            for (u,w) in E:
                if w==v:
                    predecesores.append(u)
                elif u==v:
                    predecesores.append(w)


        return predecesores

    def anadir_nodo(self,v):


        if v not in self.V:
            self.V.append(v)
        else:
            print ('ya existe el nodo '+str(v))



    def anadir_arco(self,(u,v)):

        if self.ponderado==False:

            if u not in self.V:
                self.V.append(u)
            if v not in self.V:
                self.V.append(v)

            if self.dirigido:

                if (u,v) not in self.E:

                    self.E.append((u,v))
                    self.pesos[(u,v)]=1.0
                else:
                    print ('ya existe el arco '+str((u,v)))
            else:
                self.E.append((u,v))
                self.E.append((v,u))
                self.pesos[(u,v)]=1.0
                self.pesos[(v,u)]=1.0

        else:

            if u not in self.V:
                self.V.append(u)
            if v not in self.V:
                self.V.append(v)

            if self.dirigido:

                if (u,v) not in self.E:

                    self.E.append((u,v))
                    print('Por favor indique el peso del nuevo arco: '+str((u,v)))
                else:
                    print ('ya existe el arco '+str((u,v)))
            else:

                if (u,v) not in self.E:
                    self.E.append((u,v))
                    self.E.append((v,u))
                    print('Por favor indique el peso del nuevo arco: '+str((u,v))+
					'y el de su inverso '+str((v,u)))
                else:
                    print ('ya existen los arcos '+str((u,v))+' y '+str((v,u)))





    def eliminar_arco(self,(u,v)):

                e=self.E.index((u,v))
                del self.E[e]
                del self.pesos[(u,v)]


    def eliminar_nodo(self,v):

        del self.V[v]

        for (u,w) in self.E:
            if u==v or w==v:
                e=self.E.index((u,w))
                del self.E[e]

