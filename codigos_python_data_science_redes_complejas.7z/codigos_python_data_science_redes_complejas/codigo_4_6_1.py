# -*- coding: utf-8 -*-
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import numpy as np
import scipy

n=100
N=3*n

a = scipy.zeros([3*n])
b = scipy.zeros([3*n])

P=[[],[],[]]


for i in range(n):
    a[i] = np.random.normal(2, 0.5)
    b[i] =np.random.normal(2, 0.5)
    P[0].append((a[i],b[i]))

for i in range(n):
    a[i+n] = np.random.normal(4, 0.5)
    b[i+n] =np.random.normal(4, 0.5)
    P[1].append((a[i+n],b[i+n]))
for i in range(n):
    a[i+2*n] = np.random.normal(4, 0.5)
    b[i+2*n] =np.random.normal(1, 0.5)
    P[2].append((a[i+2*n],b[i+2*n]))

Kmeans(3) #(codigo 4.3.1)
d=np.zeros((N, 3))
#Los centroides deben definirse como variable global en el odigo 4.3.1
#o bien obtenerlos de la función Kmeans()
for i in range(N):
    for j in range(3):
        d[i,j]=np.sqrt((a[i]-centroides[j,0])**2+(b[i]-centroides[j,1])**2)

C=[[],[],[]]

for i in range(N):
    for j in range(3):
        if d[i,j]==min(d[i,0],d[i,1],d[i,2]):
            C[j].append((a[i],b[i]))

def etiquetaP(x):
    for i in range(3):
        if x in P[i]:
            return i
def etiquetaC(x):
    for i in range(3):
        if x in C[i]:
            return i

aa=0
bb=0
cc=0
dd=0

for i in range(N-1):
    for j in range(i+1,N):
        a1=etiquetaP((a[i],b[i]))
        b1=etiquetaP((a[j],b[j]))
        c1=etiquetaC((a[i],b[i]))
        d1=etiquetaC((a[j],b[j]))
        if a1==b1 and c1==d1:
            aa=aa+1
        if a1==b1 and c1!=d1:
            bb=bb+1
        if a1!=b1 and c1==d1:
            cc=cc+1
        if a1!=b1 and c1!=d1:
            dd=dd+1

Rand=float(aa+dd)/float((N*(N-1)/2))
Jaccard=float(aa)/float(aa+bb+cc)
Fowlknes_and_Mallows=np.sqrt((float(aa)/(aa+bb))*(float(aa)/(aa+cc)))
gamma=aa/float((N*(N-1)/2))

mu_u=(aa+cc)/float((N*(N-1)/2))
mu_v=(aa+bb)/float((N*(N-1)/2))
sigma_u=(aa+cc)/float((N*(N-1)/2))-((aa+cc)/float((N*(N-1)/2)))**2
sigma_v=(aa+bb)/float((N*(N-1)/2))-((aa+bb)/float((N*(N-1)/2)))**2

uu=np.zeros((N,N))
vv=np.zeros((N,N))
numerador_gamma_norm=0
for i in range(N-1):
    for j in range(i+1,N):
        if etiquetaP((a[i],b[i]))==etiquetaP((a[j],b[j])):
            uu[i,j]=1
        else:
            uu[i,j]=0
        if etiquetaC((a[i],b[i]))==etiquetaC((a[j],b[j])):
            vv[i,j]=1
        else:
            vv[i,j]=0
        numerador_gamma_norm=numerador_gamma_norm+(uu[i,j]-mu_u)*(vv[i,j]-mu_v)

gamma_normalizado=numerador_gamma_norm/(np.sqrt(sigma_u)*np.sqrt(sigma_u)*float((N*(N-1)/2)))

print(u'Indice Rand:')
print(Rand)
print(u'Indice de Jaccard:')
print(Jaccard)
print(u'Indice de Fowlknes and Mallows:')
print(Fowlknes_and_Mallows)
print(u'Indice gamma:')
print(gamma)
print(u'Indice gamma normalizado:')
print(gamma_normalizado)