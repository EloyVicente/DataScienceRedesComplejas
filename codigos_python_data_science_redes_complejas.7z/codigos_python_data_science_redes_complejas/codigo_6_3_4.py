# -*- coding: utf-8 -*-


import numpy as np
import matplotlib.pyplot as plt

nodos=range(12)

P=np.zeros((12,12))

relaciones={0:[8],1:[0,9],2:[0,4,10],3:[0,7,10],4:[0,1,3,11]
,5:[1,4,11],6:[2,4,11],7:[8],8:[7],9:[9],10:[10],11:[11]}

for i in range(12):
    for j in relaciones[i]:
        P[i,j]=1.0/len(relaciones[i])
pi_0=[1.0/7 for i in range(7)]+[0.0 for i in range(5)]
Q=np.dot(P,P)

for i in range(10000):
    Q=np.dot(Q,P)

dominancia=np.dot(pi_0,Q)

plt.figure()
plt.bar(np.arange(5), dominancia[7:])
plt.title(u'Dominancia de las personas fisicas\n' ' sobre la red opaca de empresas')
plt.xticks(np.arange(6), range(7,12), rotation = 45)
plt.xlabel(u'Personas fisicas')
plt.ylabel('Dominancia')
plt.savefig('markov-empresas-opacidad.png',dpi=350)
