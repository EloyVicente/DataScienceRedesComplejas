# -*- coding: utf-8 -*-

import numpy as np
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn import linear_model, decomposition, svm, manifold
import csv
from sklearn import svm
from sklearn import lda
from sklearn.linear_model import LogisticRegression
from sklearn import cross_validation
from sklearn import decomposition

tabla_datos='factureras.csv'

T=list(csv.reader(open(tabla_datos), delimiter=','))

M=[]
clases=[]

for i in T[1:]:
    M_=[]
    fila=i[0].split(';')
    for j in fila[1:-1]:
        M_.append(float(j))
    clases.append(fila[-1])
    M.append(M_)

M=np.array(M)

M_normalizada=np.array(M)

for i in range(len(M)):
        for j in range(len(M[i])):
            if np.max(M[:,j])!=0:
                M_normalizada[i,j]=(M[i,j]-np.mean(M[:,j]))/np.std(M[:,j])
            else:
                M_normalizada[i,j]=0.0



pca=decomposition.PCA(n_components=20)
M_reducida=pca.fit_transform(M_normalizada)

color_=[]
for i in clases:
    if i=='1':
        color_.append('r')
    else:
        color_.append('b')
        
