# -*- coding: utf-8 -*-


import Queue

def recorrido_anchura_arbol(G,s):

    A=[]
    Q=Queue.Queue()
    Q.put(s)

    while not Q.empty():
        u=Q.get()
        print u,
        A.append(u)
        for v in G.sucesores(u):
            Q.put(v)

    return A