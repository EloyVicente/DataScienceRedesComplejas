# -*- coding: utf-8 -*-

import scipy.io.wavfile
import matplotlib.pyplot as plt

plt.figure()
sample_rate,X=scipy.io.wavfile.read('ruta1/metal.00000.wav')
plt.specgram(X,Fs=sample_rate,xextent=(0,30))
plt.title('rock metal')
plt.xlabel('tiempo en segundos')
plt.ylabel('frecuencia en hertzios')
plt.savefig('metal.png',dpi=400)

plt.figure()
sample_rate,X=scipy.io.wavfile.read('ruta2/blues.00000.wav')
plt.specgram(X,Fs=sample_rate,xextent=(0,30))
plt.title('blues')
plt.xlabel('tiempo en segundos')
plt.ylabel('frecuencia en hertzios')
plt.savefig('blues.png',dpi=400)

plt.figure()
sample_rate,X=scipy.io.wavfile.read('ruta3/classical.00000.wav')
plt.specgram(X,Fs=sample_rate,xextent=(0,30))
plt.title('clasica')
plt.xlabel('tiempo en segundos')
plt.ylabel('frecuencia en hertzios')
plt.savefig('clasical.png',dpi=400)


