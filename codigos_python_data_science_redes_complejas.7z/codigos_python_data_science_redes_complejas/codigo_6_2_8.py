# -*- coding: utf-8 -*-


def componentes_conexas(G):

    componentes={}
    for u in G.V:
        componentes[u]=set([u])
        for v in G.V:
            alcanzados=recorrido_anchura(G,s=u)
            if v in alcanzados and v not in componentes[u]:
                componentes[u].add(v)

    componentes_conexas_aux=[]
    componentes_conexas=[]
    for i in componentes.values():
            if i not in componentes_conexas_aux:
                componentes_conexas_aux.append(i)

    a_eliminar=[]
    for i in componentes_conexas_aux:
        for j in componentes_conexas_aux:
            if i!=j and i.issubset(j) and i not in a_eliminar:
                a_eliminar.append(i)

    for i in componentes_conexas_aux:
        if i not in a_eliminar:
            componentes_conexas.append(i)

    return componentes_conexas