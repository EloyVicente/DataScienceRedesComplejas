# -*- coding: utf-8 -*-

def distancia_coseno(p, q):

    p = np.array(p).flatten()
    q = np.array(q).flatten()
    return -np.dot(p,q.T) / (np.sqrt(np.dot(p,p.T)*np.dot(q,q.T)))

def predecir(X):
    global Q
    minDist = np.finfo('float').max
    minClass = -1
    Q = proyeccion(W, X.reshape(1,-1), mu)
    for i in xrange(len(proyecciones)):
        #print proyecciones[i]

        dist = distancia_coseno(proyecciones[i], Q)

        if dist < minDist:
            minDist = dist
            minClass = y[i]

    return minClass

proyecciones=[]
for i in range(len(X)):
    proyecciones.append(proyeccion(W, X[i].reshape(1,-1), mu)[0])
