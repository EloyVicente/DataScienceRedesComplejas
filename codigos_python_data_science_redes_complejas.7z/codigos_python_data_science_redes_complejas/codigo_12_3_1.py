# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-

import unicodedata
import glob
import numpy as np
import os
from nltk import *
from nltk.corpus import PlaintextCorpusReader
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

def carga(textos_originales):

   f={}

   for i in range(len(textos_originales)):
         f[i]=file(textos_originales[i])
         txt=f[i].read()
         txt=unicode(txt, "latin2")
         txt=unicodedata.normalize('NFD', txt).encode('ascii','ignore')

         f[i].close()
         txt=txt.lower()
         txt=txt.replace('\n',' ')

         char_ok=[32]+range(97,122)
         for j in range(256):
             if j not in char_ok:
                 txt=txt.replace(chr(j),'')

         archi=open(directorio_textos_limpios+'/'+str(i)+'.txt','w')
         archi.write(txt)
         archi.close()

def matriz_frecuencias(textos_originales,frecuencia_min):

   carga(textos_originales)

   corpus = PlaintextCorpusReader(directorio_textos_limpios,'.*\.txt')
   a=sorted(corpus.fileids())

   frecuencias={}
   A=[]
   B=[]
   longitud=np.zeros(len(textos_originales))

   for i in range(len(textos_originales)):

      frecuencias=FreqDist(corpus.words(a[i]))
      N=len(corpus.words(a[i]))
      longitud[i]=N
      for w in set(corpus.words(a[i])):
                     if (len(w) > 4 and frecuencias[w] > float(frecuencia_min*N/100)):
                           A.append(w)
                           B.append(frecuencias[w])
   C=list(set(A))

   M=np.zeros((len(textos_originales),len(C)))

   for i in range(len(textos_originales)):
            for j in range(len(C)):
                  M[i,j]=corpus.words(a[i]).count(C[j])

   return M,longitud,C

def mds(M):
   s=1.0/len(M)
   D=np.zeros((len(M),len(M)))

   for i in range(len(M)):
      for j in range(len(M)):
         D[i,j]=(-0.5)*np.sqrt(np.dot(M[i]-M[j],M[i]-M[j]))
         #print D[i,j]

   UNO=np.ones((1,len(M)))
   B=np.dot(np.identity(len(M))-
         s*np.dot(UNO.transpose(),UNO),
         D,np.identity(len(M))-s*np.dot(UNO.transpose(),
                                 UNO))

   lambd , vec = np.linalg.eig(B)

   autovalores=sorted(lambd,reverse = True)

   ############################## Rotacion  y Proyeccion ###########
   DELTA=np.zeros((len(M),len(M)))
   DELTA[0,0]=np.sqrt(autovalores[0])
   DELTA[1,1]=np.sqrt(autovalores[1])

   X_t=np.dot(vec,DELTA)

   A=X_t[:,0]
   B=X_t[:,1]

   return A,B

def visualizacion(M):

   n=len(M)

   A,B=mds(M)

   corpus = PlaintextCorpusReader(directorio_textos_limpios,'.*\.txt')
   a=sorted(corpus.fileids())

   plt.close ()
   figura_visualizacion=plt.figure("visualizacion")

   k=range(0,n-1)
   plt.scatter(A,B)
   for i in range(n):
       l=list(a[i])
       etiqueta=''
       for j in range(len(a[i])-4):
         etiqueta=etiqueta+l[:-4][j]
       plt.text(A[i]+0.15,B[i],etiqueta, fontsize = 10,
          horizontalalignment='center', verticalalignment='center')
   plt.title('Visualizacion MDS')
   plt.savefig('visualizacion_textos.png',dpi=400)

def Kmeans(a,b,clusters):

   n_digits=clusters
   L=np.array([a,b]).transpose()
   reduced_data = L
   kmeans = KMeans(init='k-means++', n_clusters=n_digits, n_init=5)
   kmeans.fit(reduced_data)
   return reduced_data , kmeans

def clasificar(M,numero_clusters):

   A,B=mds(M)
   corpus = PlaintextCorpusReader(directorio_textos_limpios,'.*\.txt')

   a=sorted(corpus.fileids())

   clusters=numero_clusters

   clases1=Kmeans(A,B,clusters)

   reduced_data=clases1[0]
   kmeans=clases1[1]

   h = .01

   clases=Kmeans(A,B,numero_clusters)

   reduced_data=clases[0]
   kmeans=clases[1]

   x_min, x_max = reduced_data[:, 0].min()-1, reduced_data[:, 0].max()+1
   y_min, y_max = reduced_data[:, 1].min()-1, reduced_data[:, 1].max()+1
   xx, yy = np.meshgrid(np.arange(x_min, x_max, h), np.arange(y_min, y_max, h))
   Z = kmeans.predict(np.c_[xx.ravel(), yy.ravel()])
   Z = Z.reshape(xx.shape)
   plt.imshow(Z, interpolation='nearest',
               extent=(xx.min(), xx.max(), yy.min(), yy.max()),
               cmap=plt.cm.Paired,
               aspect='auto', origin='lower')

   plt.plot(reduced_data[:, 0], reduced_data[:, 1], 'k.')

   centroids = kmeans.cluster_centers_
   plt.scatter(centroids[:, 0], centroids[:, 1],
               marker='x', s=169, linewidths=3,
               color='w', zorder=10)
   for i in range(len(M)):
      l=list(a[i])
      etiqueta=''
      for j in range(len(a[i])-4):
         etiqueta=etiqueta+l[:-4][j]
      plt.text(A[i],B[i]+0.1,etiqueta, fontsize = 10,
				horizontalalignment='center', verticalalignment='center')

   plt.title('Algoritmo K-means clustering sobre vista MDS \n '
                u'Los centroides estan marcados con una X blanca')
   plt.xlim(x_min, x_max)
   plt.ylim(y_min, y_max)
   plt.xticks(())
   plt.yticks(())
   plt.savefig('clasificacion_textos.png',dpi=400)
   plt.show()


frecuencia_min=1
ruta_del_directorio='ruta/*.txt'
textos_originales=glob.glob(ruta_del_directorio)
r=len(textos_originales)
directorio_actual=os.getcwd()
if os.path.exists(str(directorio_actual)+'/textos_limpios')==False:
    os.mkdir(str(directorio_actual)+'/textos_limpios')
directorio_textos_limpios=str(directorio_actual)+'/textos_limpios'

M,l,C=matriz_frecuencias(textos_originales,frecuencia_min)
plt.figure()
visualizacion(M)
plt.figure()
num_clusters=3
clasificar(M,numero_clusters=num_clusters)

