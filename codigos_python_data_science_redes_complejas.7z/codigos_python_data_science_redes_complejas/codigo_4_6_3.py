# -*- coding: utf-8 -*-
"""
Created on Sun Jun 25 11:06:57 2017

@author: Eloy
"""

import scipy
import scipy.cluster.hierarchy as sch
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.distance import squareform

n=6

# Generamos n puntos aleatorios en el plano y su matriz de distancias

x = scipy.rand(n)
y = scipy.rand(n)
D = scipy.zeros([n,n])
for i in range(n):
    for j in range(n):
        D[i,j] = abs(x[i] - x[j])+ abs(y[i] - y[j])


plt.close ()
fig = plt.figure(u"Clustering jerarquico")

# Dibujamos la nube de puntos
plt.subplot(121)
plt.scatter(x,y)
a=[]
for i in range(n):
    a.append(str(i))

    plt.text(x[i],y[i]+0.025, a[i], fontsize = 10,
             horizontalalignment='center',
             verticalalignment='center')

plt.title(u'Nube de puntos')

plt.subplot(122)

# Dibujamos el dendrograma.

Y = sch.linkage(D, method='single')
fig = plt.figure(u"Clustering jerarquico")
Z = sch.dendrogram(Y)
plt.title(u'Dedrograma sobre \n' 'la nube de puntos')

fig.show()
fig.savefig('dendrogramav3')

# Calulamos el coeficiente de correlacion cofenetica

dm= squareform(D)
L=sch.cophenet(Y)
M=sch.cophenet(Y,dm)
v = squareform(L)

print(u'matriz cofeneica %d:')
print(v)
print(u'Indice de correlacion cofenetica:')
print(M[0])
