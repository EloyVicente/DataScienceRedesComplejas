# -*- coding: utf-8 -*-

import numpy as np
from matplotlib import pyplot as plt
import csv
from sklearn.decomposition import PCA



def pca(ruta,matriz,lista_alumnos):

    pca = PCA(n_components=2)
    pca.fit(matriz).transform(matriz)
    print(pca.explained_variance_ratio_)
    print(np.sum(pca.explained_variance_ratio_))

    proyeccion=pca.transform(matriz)

    plt.scatter(proyeccion[:,0],proyeccion[:,1])
    for i in range(len(proyeccion)):
        plt.text(proyeccion[i,0],proyeccion[i,1],lista_alumnos[i])

    plt.title(u'Proyeccion del rendimiento de los alumnos \n'
'sobre los dos primeros componentes principales')

    plt.savefig('proyeccion-alumnos-PCA.png')




def main():

    ruta='ejemplo-estudiantes.csv'
    filas=list(csv.reader(open(ruta,'rb'), delimiter=';'))

    n=len(filas)-1
    p=len(filas[2])-1

    matriz=np.zeros((n,p))

    for i in range(n+1):
        for j in range(p+1):
            filas[i][j]=filas[i][j].replace(',','.')
    for i in range(n):
        for j in range(p):
         
            matriz[i,j]=float(filas[i+1][j+1])

    plt.figure(figsize=(8,6))
    pca(ruta,matriz,lista_alumnos=np.array(filas)[:,0][1:])


if __name__ == "__main__":
    main()

