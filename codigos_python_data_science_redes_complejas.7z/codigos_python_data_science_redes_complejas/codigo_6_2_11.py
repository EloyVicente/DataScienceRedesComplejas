# -*- coding: utf-8 -*-
def todos_los_caminos(G,s,t):

    if s==t:
        return [[t]]
    visitados=[]
    caminos=[]

    for u in G.predecesores(t):
        if u not in visitados:
            for trozo_previo in todos_los_caminos(G,s,u):
                caminos.append(trozo_previo+[t])
                visitados.append(u)

    return caminos

def distancia_geodesica(G,s,t):

    caminos=todos_los_caminos(G,s,t)

    longitudes=[]
    for i in caminos:
        longitudes.append(len(i)-1)

    longitud_minima=np.min(longitudes)

    caminos_mas_cortos=[]
    for i in caminos:
         if len(i)==longitud_minima:
             caminos_mas_cortos.append(i)


    return caminos, longitud_minima