# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-

from math import sqrt

usuarios = {"usuario1": {"pelicula1": 3.5, "pelicula2": 2.0, "pelicula3": 4.5, "pelicula4": 5.0,
"pelicula5": 1.5, "pelicula6": 2.5, "pelicula7": 2.0},
"usuario2":{"pelicula1": 2.0, "pelicula2": 3.5, "pelicula8": 4.0, "pelicula4": 2.0,
"pelicula5": 3.5, "pelicula7": 3.0},"usuario3": {"pelicula1": 5.0, "pelicula2": 1.0,
"pelicula8": 1.0, "pelicula3": 3.0, "pelicula4": 5, "pelicula5": 1.0},
"usuario4": {"pelicula1": 3.0, "pelicula2": 4.0, "pelicula8": 4.5,
"pelicula4": 3.0, "pelicula5": 4.5, "pelicula6": 4.0, "pelicula7": 2.0},
"usuario5": {"pelicula2": 4.0, "pelicula8": 1.0, "pelicula3": 4.0,
"pelicula6": 4.0, "pelicula7": 1.0},
"usuario6":  {"pelicula2": 4.5, "pelicula8": 4.0, "pelicula3": 5.0,
"pelicula4": 5.0, "pelicula5": 4.5, "pelicula6": 4.0, "pelicula7": 4.0},
"usuario7": {"pelicula1": 5.0, "pelicula2": 2.0, "pelicula3": 3.0, "pelicula4": 5.0,
"pelicula5": 4.0, "pelicula6": 5.0},
"usuario8": {"pelicula1": 3.0, "pelicula3": 5.0, "pelicula4": 4.0,
"pelicula5": 2.5, "pelicula6": 3.0}
        }

pelis = {"pelicula1": {"variable1": 2.5, "variable2": 4, "variable3": 3.5, "variable4": 3,
"variable5": 5, "variable6": 4, "variable7": 1},"pelicula2": {"variable1": 2, "variable2": 5,
"variable3": 5, "variable4": 3, "variable5": 2, "variable6": 1, "variable7": 1},
"pelicula3": {"variable1": 1, "variable2": 5, "variable3": 4, "variable4": 2,
"variable5": 4, "variable6": 1, "variable7": 1},"pelicula4": {"variable1": 4,
"variable2": 5, "variable3": 4, "variable4": 4, "variable5": 1, "variable6": 5,
"variable7": 1},"pelicula5": {"variable1": 1, "variable2": 4, "variable3": 5,
"variable4": 3.5, "variable5": 5, "variable6": 1, "variable7": 1},"pelicula6": {"variable1": 1,
"variable2": 5, "variable3": 3.5, "variable4": 3, "variable5":4, "variable6": 5,
"variable7": 1},"pelicula7": {"variable1": 5, "variable2": 5, "variable3": 4,
"variable4": 2, "variable5": 1, "variable6": 1, "variable7": 1},
"pelicula8": {"variable1": 2.5, "variable2": 4, "variable3": 4,
"variable4": 1, "variable5": 1, "variable6": 1, "variable7": 1},}

def pearson(puntuaciones1, puntuaciones2):
    sum_xy = 0
    sum_x = 0
    sum_y = 0
    sum_x2 = 0
    sum_y2 = 0
    n = 0
    for key in puntuaciones1:
        if key in puntuaciones2:
            n += 1
            x = puntuaciones1[key]
            y = puntuaciones2[key]
            sum_xy += x * y
            sum_x += x
            sum_y += y
            sum_x2 += pow(x, 2)
            sum_y2 += pow(y, 2)

    denominador = sqrt(sum_x2 - pow(sum_x, 2) / n) * sqrt(sum_y2 - pow(sum_y, 2) / n)
    if denominador == 0:
        return 0
    else:
        return (sum_xy - (sum_x * sum_y) / n) / denominador


def ordenar_vecinos(nombre_pelicula, pelis,funcion_distancia):

    distancias = []
    for peli in pelis:
        if peli != nombre_pelicula:
            distancia = funcion_distancia(pelis[peli], pelis[nombre_pelicula])
            distancias.append((distancia, peli))

    distancias.sort()
    return distancias

def recomendar(nombre_usuario):



    pelis_recomendadas={}

    for i in usuarios[nombre_usuario].keys():
        if usuarios[nombre_usuario][i]>2:
            lista_pelis=ordenar_vecinos(nombre_pelicula=i, pelis=pelis,
			funcion_distancia=pearson)
            for j in lista_pelis:
                if j[0]>0.75:
                    if j[1] not in pelis_recomendadas.keys() or pelis_recomendadas[j[1]]<j[0]:
                        pelis_recomendadas[j[1]]=j[0]

    pelis_recomendadas_lista=[]
    for i in pelis_recomendadas.keys():
        pelis_recomendadas_lista.append((i,pelis_recomendadas[i]))

    pelis_recomendadas_ordenadas=sorted(pelis_recomendadas_lista, key=lambda peliculas: peliculas[1],
			reverse = True)

    return pelis_recomendadas_ordenadas


print(recomendar(nombre_usuario='usuario2'))