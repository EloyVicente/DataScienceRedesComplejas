# -*- coding: utf-8 -*-
def regresion_logistica(casos_a_predecir=[],umbral=0.5):

    clf2 = LogisticRegression()#svm.SVC()#
    scores = cross_validation.cross_val_score(clf2, M_reducida, np.array(clases), cv=10)

    clf2.fit(M_reducida, clases)
    global prediccion_regresion
    global probabilidad
    global probabilidad_invertida
    prediccion_regresion=[]
    prediccion_estricta={}
    probabilidad={}
    probabilidad_invertida={}

    for i in range(len(clases)):
        if clases[i]=='1':
            ejemplo_facturera=i
        else:
            ejemplo_no_facturera=i

    for i in range(len(casos_a_predecir)):
        prediccion_regresion.append(clf2.predict(casos_a_predecir[i]))
        probabilidad[i]=1/(1+np.exp(-(clf2.intercept_+np.dot(clf2.coef_,casos_a_predecir[i]))))
        probabilidad_invertida[probabilidad[i][0]]=i

    print ('bondad por crossvalidation: '+str(np.mean(scores)))

    color_regresion=[]

    for i in range(len(clases)):
        if clases[i]=='1':
            ejemplo_facturera=i
        else:
            ejemplo_no_facturera=i

    for i in range(len(casos_a_predecir)):
        d=clf2.predict(casos_a_predecir[i])
        if 1/(1+np.exp(-(clf2.intercept_+np.dot(clf2.coef_,casos_a_predecir[i]))))>umbral:
            prediccion_estricta[i]=1
            color_regresion.append('r')

        else:
            #color_validacion.append('r')
            prediccion_estricta[i]=0
            color_regresion.append('b')

    clf = lda.LDA(n_components=2)#svm.SVC()#
    X_r2 =clf.fit(M_reducida, clases).transform(M_reducida)
    RR=np.random.rand(len(casos_a_predecir))

    plt.figure()
    plt.scatter(X_r2[ejemplo_facturera, 0], X_r2[ejemplo_facturera, 0],
			c=color_[ejemplo_facturera],label='Factureras')
    plt.scatter(X_r2[ejemplo_no_facturera, 0], X_r2[ejemplo_no_facturera,
			0], c=color_[ejemplo_no_facturera],label='No factureras')
 
    plt.scatter(clf.transform(casos_a_predecir)[:,0],clf.transform(casos_a_predecir)[:,0]+2	
		*RR,c=color_regresion)
    plt.title(u'Predicciones de la regresion logistica \n'
			u' sobre la direccion de maxima discriminacion')
    plt.legend(loc=2)
    plt.savefig('discriminanteregresion.png')