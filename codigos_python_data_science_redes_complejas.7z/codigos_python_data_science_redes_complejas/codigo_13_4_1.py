# -*- coding: utf-8 -*-

import os, sys
import numpy as np
import PIL.Image as Image
import matplotlib.cm as cm
import matplotlib.pyplot as plt

def leer_imagenes(path, sz=None):
	c = 0
	X,y = [], []
	for nombre_directorio, nombres_directorios, archivos in os.walk(path):
		for nombre_subdirectorio in nombres_directorios:
			path_aux = os.path.join(nombre_directorio, nombre_subdirectorio)
			for archivo in os.listdir(path_aux):				
				im = Image.open(os.path.join(path_aux, archivo))
				im = im.convert("L")
    
				if (sz is not None):
					im = im.resize(sz, Image.ANTIALIAS)
				X.append(np.array(im, dtype=np.uint8))
				y.append(c)				
			c = c+1
	return [X,y]
 

def esparcir_imagenes(X):

	if len(X) == 0:
		return np.array([])
	matriz_imagenes_esparcidas = np.empty((0, X[0].size), dtype=X[0].dtype)
	for row in X:
		matriz_imagenes_esparcidas = np.vstack((matriz_imagenes_esparcidas, np.array(row).reshape(1,-1)))
	return matriz_imagenes_esparcidas



def pca(X, y, num_componentes=0):
    
    global autovalores
    [n,d] = X.shape
    if (num_componentes <= 0) or (num_componentes>n):
        num_componentes = n
    mu = X.mean(axis=0)
    X = X - mu
    if n>d:
        C = np.dot(X.T,X)
        [autovalores,autovectores] = np.linalg.eigh(C)
    else:
        C = np.dot(X,X.T)
        [autovalores,autovectores] = np.linalg.eigh(C)
        autovectores = np.dot(X.T,autovectores)
        for i in xrange(n):
            autovectores[:,i] = autovectores[:,i]/np.linalg.norm(autovectores[:,i])
        idx = np.argsort(-autovalores)
        autovalores = autovalores[idx]
        autovectores = autovectores[:,idx]
        autovalores = autovalores[0:num_componentes].copy()
        autovectores = autovectores[:,0:num_componentes].copy()
    return [autovalores, autovectores, mu]