# -*- coding: utf-8 -*-

from math import sqrt

usuarios = {"usuario1": {"pelicula1": 3.5, "pelicula2": 2.0, "pelicula3": 4.5, "pelicula4": 5.0,
"pelicula5": 1.5, "pelicula6": 2.5, "pelicula7": 2.0},
"usuario2":{"pelicula1": 2.0, "pelicula2": 3.5, "pelicula8": 4.0, "pelicula4": 2.0,
"pelicula5": 3.5, "pelicula7": 3.0},"usuario3": {"pelicula1": 5.0, "pelicula2": 1.0,
"pelicula8": 1.0, "pelicula3": 3.0, "pelicula4": 5, "pelicula5": 1.0},
"usuario4": {"pelicula1": 3.0, "pelicula2": 4.0, "pelicula8": 4.5,
"pelicula4": 3.0, "pelicula5": 4.5, "pelicula6": 4.0, "pelicula7": 2.0},
"usuario5": {"pelicula2": 4.0, "pelicula8": 1.0, "pelicula3": 4.0,
"pelicula6": 4.0, "pelicula7": 1.0},
"usuario6":  {"pelicula2": 4.5, "pelicula8": 4.0, "pelicula3": 5.0,
"pelicula4": 5.0, "pelicula5": 4.5, "pelicula6": 4.0, "pelicula7": 4.0},
"usuario7": {"pelicula1": 5.0, "pelicula2": 2.0, "pelicula3": 3.0, "pelicula4": 5.0,
"pelicula5": 4.0, "pelicula6": 5.0},
"usuario8": {"pelicula1": 3.0, "pelicula3": 5.0, "pelicula4": 4.0,
"pelicula5": 2.5, "pelicula6": 3.0}
        }

def pearson(puntuaciones1, puntuaciones2):
    sum_xy = 0
    sum_x = 0
    sum_y = 0
    sum_x2 = 0
    sum_y2 = 0
    n = 0
    for key in puntuaciones1:
        if key in puntuaciones2:
            n += 1
            x = puntuaciones1[key]
            y = puntuaciones2[key]
            sum_xy += x * y
            sum_x += x
            sum_y += y
            sum_x2 += pow(x, 2)
            sum_y2 += pow(y, 2)

    denominador = sqrt(sum_x2 - pow(sum_x, 2) / n) * sqrt(sum_y2 - pow(sum_y, 2) / n)
    if denominador == 0:
        return 0
    else:
        return (sum_xy - (sum_x * sum_y) / n) / denominador

def distancia_Manhattan(puntuaciones1, puntuaciones2):

    distancia = 0
    puntuaciones_comunes = False
    for key in puntuaciones1:
        if key in puntuaciones2:
            distancia += abs(puntuaciones1[key] - puntuaciones2[key])
            puntuaciones_comunes = True
    if puntuaciones_comunes:
        return distancia
    else:
        return -1


def ordenar_vecinos(nombre_usuario, usuarios,funcion_distancia):

    distancias = []
    for usuario in usuarios:
        if usuario != nombre_usuario:
            distancia = funcion_distancia(usuarios[usuario], usuarios[nombre_usuario])
            distancias.append((distancia, usuario))
    distancias.sort()

    if funcion_distancia==distancia_Manhattan:
        return distancias

    elif funcion_distancia==pearson:
        distancias.reverse()
        return distancias


    #return distancias

def recomendar(nombre_usuario, usuarios,funcion_distancia=distancia_Manhattan):

    mas_cercano = ordenar_vecinos(nombre_usuario, usuarios,funcion_distancia)[0][1]

    recomendaciones = []
    puntuaciones_vecino = usuarios[mas_cercano]
    puntuaciones_usuario = usuarios[nombre_usuario]
    for peliculas in puntuaciones_vecino:
        if not peliculas in puntuaciones_usuario:
            recomendaciones.append((peliculas, puntuaciones_vecino[peliculas]))

    return sorted(recomendaciones, key=lambda peliculas: peliculas[1], reverse = True)

print( recomendar('usuario2', usuarios,pearson))
print( recomendar('usuario2', usuarios,distancia_Manhattan))
