# -*- coding: utf-8 -*-
def recorrido_completo_primero_anchura(G):

    visitados=[]

    for v in G.V:
        if v not in visitados:
            visitados=visitados+recorrido_anchura(G,v)

    return set(visitados)

def recorrido_completo_primero_profundidad(G):

    visitados=[]

    for v in G.V:
        if v not in visitados:
            visitados=visitados+recorrido_profundidad(G,v)

    return set(visitados)