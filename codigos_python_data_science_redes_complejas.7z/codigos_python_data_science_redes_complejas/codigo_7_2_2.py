# -*- coding: utf-8 -*-

import graph_tool.all as gt

g=gt.Graph()

for i in usuarios.keys():
    g.add_vertex()

nombre = g.new_vertex_property("string")
apellidos = g.new_vertex_property("string")
profesion = g.new_vertex_property("string")
edad = g.new_vertex_property("int")
for u in g.vertices():
    nombre[u]=usuarios[u]['nombre']
    apellidos[u]=usuarios[u]['apellidos']
    profesion[u]=usuarios[u]['profesion']
    edad[u]=usuarios[u]['edad']

tipo_relacion = g.new_edge_property("string")

e1=g.add_edge(0,1)
tipo_relacion[e1]='familiar'
e2=g.add_edge(0,2)
tipo_relacion[e2]='familiar'
e3=g.add_edge(1,2)
tipo_relacion[e3]='familiar'
e4=g.add_edge(2,5)
tipo_relacion[e4]='amigos'
e5=g.add_edge(5,3)
tipo_relacion[e5]='familiar'
e6=g.add_edge(3,4)
tipo_relacion[e6]='familiar'
e7=g.add_edge(4,5)
tipo_relacion[e7]='familiar'
e8=g.add_edge(0,3)
tipo_relacion[e8]='colegas'
