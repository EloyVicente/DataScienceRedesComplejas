# -*- coding: utf-8 -*-

def Bellman_Ford(G,s,t,infinito=sys.maxint):
    global D
    D={}
    for v in G.V:
        D[v,0]=infinito

    D[t,0]=0
    for i in range(1,len(G.V)):

        for v in G.V:
            if len(G.sucesores(v))>0:
               D[v,i]=np.min([D[u,i-1]+G.pesos[(v,u)] for u in G.sucesores(v)])
            else:
                D[v,i]=infinito

    return np.min([D[s,i] for i in range(len(G.V))])

