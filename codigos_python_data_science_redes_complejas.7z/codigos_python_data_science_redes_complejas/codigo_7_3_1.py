# -*- coding: utf-8 -*-

import networkx as nx
import matplotlib.pyplot as plt

g=nx.read_graphml('miserables.graphml')

pos=nx.spring_layout(g)
color_nodos={}
etiquetas_nodos ={}
for i in g.nodes():
    etiquetas_nodos[i]= g.node[i]['name']
    if g.node[i]['name']=='JV':
        color_nodos[i]='b'
    else:
        color_nodos[i]='r'

nx.draw(g,pos=pos)
nx.draw_networkx_nodes(g,pos,node_color=color_nodos.values())
nx.draw_networkx_labels(g,pos,labels=etiquetas_nodos)

plt.axis('off')
plt.savefig('lesmiserablesnet.png',dpi=350)
plt.show ()
