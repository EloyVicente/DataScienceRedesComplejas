# -*- coding: utf-8 -*-

import numpy as np

A=np.array([[1/2.0,1/2.0,0.0],[1/3.0,1/3.0,1/3.0],[1/2.0,0.0,1/2.0]])

def potencia(A,k):

    B=A
    for i in range(k-1):
        B=np.dot(B,A)

    return B


