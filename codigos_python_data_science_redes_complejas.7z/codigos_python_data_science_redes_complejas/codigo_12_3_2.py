# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-

import unicodedata

def busqueda_palabras(textos_originales,expresiones_claves):

   f={}
   global txt
   frec={}
   for i in range(len(textos_originales)):
         f[i]=file(textos_originales[i])
         txt=f[i].read()
         txt=unicode(txt, "latin2")
         txt=unicodedata.normalize('NFD', txt).encode('ascii','ignore')

         f[i].close()
         txt=txt.lower()
         txt=txt.replace('\n',' ')

         char_ok=[32]+range(97,122)
         for j in range(256):
             if j not in char_ok:
                 txt=txt.replace(chr(j),'')

         for k in expresiones_claves:
             frec[k,i]=txt.count(k)

   return frec