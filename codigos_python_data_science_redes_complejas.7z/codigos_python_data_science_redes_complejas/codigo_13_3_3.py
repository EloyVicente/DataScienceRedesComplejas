# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import numpy as np
from numpy import pi

def mezcla(F,A,n):



    f1=F[0]
    dt = 1.0 / (f1 * 16)  # Espaciado, 16 puntos por periodo
    t = np.linspace(0, (n - 1) * dt, n)  # Intervalo de tiempo en segundos
    y= A[0]*np.sin(2 * pi * f1 * t)

    for i in range(1,len(F)):
        f=F[i]
        dt = 1.0 / (f * 16)  # Espaciado, 16 puntos por periodo
        y=y+A[i]*np.sin(2 * pi * f * t)


    plt.figure()
    plt.plot(t, y)
    #plt.plot(t, y, 'ko')
    plt.xlabel('Tiempo (s)')
    plt.ylabel('$y(t)$')
    if len(F)>1:
        plt.title(u'Senal mezclada')
    else:
        plt.title(u'Senal senoidal simple')
    plt.savefig('transformada_fourier_0.png',dpi=400)
    return y



def transformada_fourier(F,A,n):

    dt = 1.0 / (F[0] * 16)

    y=mezcla(F,A,n)

    from scipy.fftpack import fft, fftfreq
    Y = fft(y) / n  # Normalizada
    frq = fftfreq(n, dt)  # Recuperamos las frecuencias
    minimo=np.min(F)-np.min(F)/10,
    maximo=np.max(F)+np.max(F)/10
    plt.figure()

    plt.vlines(frq, 0, Y.imag)  # Representamos la parte imaginaria
    plt.ylabel('Parte imaginaria de $Y$')
    plt.xlabel('Frecuencia')
    if len(F)>1:
        plt.title(u'Transformada de Fourier de las senales mezcladas')
    else:
        plt.title(u'Transformada de Fourier de una senal simple')

    plt.savefig('transformada_fourier_1.png',dpi=400)

    return Y


F=[40.0,10.0,20.0]
A=[2.0,5.0,4.0]
n = 2 ** 6
transformada_fourier(F,A,n)

F=[4.0]
A=[2.0]
n = 2 ** 6

transformada_fourier(F,A,n)