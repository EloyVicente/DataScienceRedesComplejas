# -*- coding: utf-8 -*-

import numpy as np
from sklearn.lda import LDA

from matplotlib import pyplot as plt

mu1,s1=5, 1
mu2,s2=-3, 1
mu3,s3=1, 1

X1=mu1+s1*np.random.randn(250,2)
X2=mu2+s2*np.random.randn(250,2)
X3=mu3+s3*np.random.randn(250,2)
X=np.array(np.concatenate((X1,X2,X3)))

plt.scatter(X1[:,0],X1[:,1],c='r',label='Clase 1')
plt.scatter(X2[:,0],X2[:,1],c='g',label='Clase 2')
plt.scatter(X3[:,0],X3[:,1],c='b',label='Clase 3')
plt.title(u'Poblaciones originales para el entrenamiento \n'
u' del modelo de clasificacion')
plt.legend(loc=2)
plt.savefig('LDA.png')

etiqueta1=np.ones(len(X1))
etiqueta2=2*np.ones(len(X2))
etiqueta3=3*np.ones(len(X3))
etiquetas=np.concatenate((etiqueta1,etiqueta2,etiqueta3))

clf=LDA()
clf.fit(X,etiquetas)
LDA(priors=None)