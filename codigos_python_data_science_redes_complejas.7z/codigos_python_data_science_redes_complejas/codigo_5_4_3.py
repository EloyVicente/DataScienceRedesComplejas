# -*- coding: utf-8 -*-


def representacion_probabilidad():

    prob=[]
    for i in probabilidad.keys():
        prob.append(probabilidad[i][0])
    plt.figure(figsize=(10,5))
    prob.sort()

    for i in probabilidad_invertida.keys():
        plt.scatter(probabilidad_invertida[i],int(clases[probabilidad_invertida[i]]),c='w')

    plt.plot(prob, c='r')
    plt.annotate('Factureras', xy=(150, 1.05))
    plt.annotate('No Factureras', xy=(-17, 0.05))
    plt.title(u'Representacion de la probabilidad \n'
			u'de pertenencia al colectivo de empresas factureras')

    plt.savefig('probabilidadfactureras.png')
