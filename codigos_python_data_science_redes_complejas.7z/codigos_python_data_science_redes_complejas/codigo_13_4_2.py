# -*- coding: utf-8 -*-

def normalizar(X, minimo, maximo):
	X = np.array(X)
	minX, maxX = np.min(X), np.max(X)

	X = X - float(minX)
	X = X / float((maxX - minX))

	X = X * (maximo-minimo)
	X = X + minimo

	return X
