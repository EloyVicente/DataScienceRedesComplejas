# -*- coding: utf-8 -*-

from numpy import random


cadena=[]

a=random.random()
i=0
if a<1/3.0:
    cadena.append(0)
elif a<2/3.0:
    cadena.append(1)
else:
    cadena.append(2)

while i<100:

    if cadena[i]==0:
        a=random.random()
        if a<1/2.0:
            cadena.append(0)
        else:
            cadena.append(1)

    elif cadena[i]==1:
        a=random.random()
        if a<1/3.0:
            cadena.append(0)
        elif a<2/3.0:
            cadena.append(1)
        else:
            cadena.append(2)

    else:
        a=random.random()
        if a<1/2.0:
            cadena.append(0)
        else:
            cadena.append(2)

    i=i+1
