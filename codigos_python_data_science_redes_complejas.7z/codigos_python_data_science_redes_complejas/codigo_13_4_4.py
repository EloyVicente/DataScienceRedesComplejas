# -*- coding: utf-8 -*-

def proyeccion(W, X, mu=None):
	if mu is None:
		return np.dot(X,W)
	return np.dot(X - mu, W)

def reconstruir(W, Y, mu=None):
	if mu is None:
		return np.dot(Y,W.T)
	return np.dot(Y, W.T) + mu

steps=[i for i in xrange(10, min(len(X), 320), 20)]
E = []
for i in xrange(min(len(steps), 16)):
    numEvs = steps[i]
    P = proyeccion(W[:,0:numEvs], X[0].reshape(1,-1), mu)
    R = reconstruir(W[:,0:numEvs], P, mu)
    # reshape and append to plots
    R = R.reshape(X[0].shape)
    E.append(normalizar(R,0,255))
    # plot them and store the plot to "python_reconstruction.pdf"
subplot(titulo=u"Reconstrucci\'on de las caras de AT&T Facedatabase", imagenes=E, filas=4, columnas=4,
 subtitulo="Autovectores", subtitulos=steps ,colormap=cm.gray, archivo_figura="reconstruccion_caras_.png")