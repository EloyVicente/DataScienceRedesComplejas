# -*- coding: utf-8 -*-

import numpy as np
from numpy import random
import pylab as py
import scipy
from scipy import signal
import matplotlib.pyplot as plt
from sklearn.decomposition import FastICA

N=1000
t = np.linspace(0, 10, N)
S=np.zeros((2,N))
X=np.zeros((2,N))

#Fuentes originales:

S1=np.sin(7*np.pi*t)
S2=signal.sawtooth(2*np.pi*t)

#Senales grabadas:

X[0]=2*S1-3*S2+ np.random.random(size=N)
X[1]=2*S1+4*S2+ np.random.random(size=N)

#descomposicion ICA:

ica = FastICA()
S_ = ica.fit_transform(X.T)
A_ = ica.mixing_

assert np.allclose(X.T, np.dot(S_, A_.T) + ica.mean_)

#Representacion:

fig=py.figure()
py.subplot(321)
py.plot(S1)
plt.title('Primera fuente (s1)')
py.subplot(322)
py.plot(S2)
plt.title('Segunda fuente (s2)')
py.subplot(323)
py.plot(X.T[:,0])
plt.title(u'Primera se\~{n}al(x1)')
py.subplot(324)
py.plot(X.T[:,1])
plt.title(u'Segunda se\~{n}al (x2)')
py.subplot(325)
py.plot(S_[:,0])
plt.title('Primera componente')
py.subplot(326)
py.plot(S_[:,1])
plt.title('Segunda componente')

fig.suptitle(u'Separacion ciega de fuentes con FASTICA')

py.show()