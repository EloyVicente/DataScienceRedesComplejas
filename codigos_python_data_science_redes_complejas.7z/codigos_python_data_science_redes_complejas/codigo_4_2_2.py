# -*- coding: utf-8 -*-

import numpy as np
import scipy
import scipy.cluster.hierarchy as sch
import matplotlib.pyplot as plt
import scipy.spatial.distance


datos=np.loadtxt('DatosComunidades.txt')
covar = np.cov(datos, rowvar=0)
D = scipy.zeros([19,19])
for i in range(19):
    for j in range(19):
        D[i,j]=scipy.spatial.distance.mahalanobis(datos[i],datos[j],covar)


# Dibujamos el dendrograma.
nombres=[u'Andalucia','uAragon','Asturias', 'Baleares', 'Canarias',
         'Cantabria', u'Cast.Leon', u'Cast. La Mancha', u'Cataluna',
         'C. Valenciana', 'Extremadura', 'Galicia', 'Madrid', 'Reg. Murcia', 'Navarra',
         u'Pais Vasco', 'La Rioja', 'Ceuta', 'Melilla']

fig = plt.figure(u"Clustering jerarquico",figsize=(16,6))
Y = sch.linkage(D, method='centroid')
Z = sch.dendrogram(Y,labels=nombres)
plt.title(u'Dedrograma sobre \n' u'comunidades autonomas espanolas')

fig.show()
fig.savefig("clustering2.png")