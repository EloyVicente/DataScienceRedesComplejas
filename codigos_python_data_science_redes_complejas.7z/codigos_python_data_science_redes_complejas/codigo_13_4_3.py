# -*- coding: utf-8 -*-


def subplot(titulo, imagenes, filas, columnas, subtitulo="subplot", subtitulos=[], colormap=cm.gray, archivo_figura=None):
	fig = plt.figure()

	fig.text(.5, .95, titulo, horizontalalignment='center',fontsize=10) 
	for i in xrange(len(imagenes)):
		ax0 = fig.add_subplot(filas,columnas,(i+1))
		plt.setp(ax0.get_xticklabels(), visible=False)
		plt.setp(ax0.get_yticklabels(), visible=False)
		if len(subtitulos) == len(imagenes):
			plt.title("%s #%s" % (subtitulo, str(subtitulos[i])),fontsize=10)
		else:
			plt.title("%s #%d" % (subtitulo, (i+1)),fontsize=10)
		plt.imshow(np.array(imagenes[i]), cmap=colormap)
	if archivo_figura is None:
		plt.show()
	else:
		fig.savefig(archivo_figura)

path='ruta/faces'

[X,y] = leer_imagenes(path)

[D, W, mu] = pca(esparcir_imagenes(X), y)


E = []
for i in xrange(min(len(X), 16)):
		e = W[:,i].reshape(X[0].shape)
		E.append(normalizar(e,0,255))

subplot(titulo="Eigenfaces para las caras de AT&T Facedatabase", imagenes=E, filas=4, columnas=4, 
        subtitulo="Eigenface", colormap=cm.jet, archivo_figura="eigenfaces_ATT_Facedatabase.png")
