# -*- coding: utf-8 -*-


def analisis_discriminante(casos_a_predecir=[]):

    clf = lda.LDA(n_components=1)#svm.SVC()#
    global X_r2
    X_r2 =clf.fit(M_reducida, clases).transform(M_reducida)
    #LDA(priors=None)
    scores = cross_validation.cross_val_score(clf, M_reducida, np.array(clases), cv=10)

    for i in range(len(clases)):
        if clases[i]=='1':
            ejemplo_facturera=i
        else:
            ejemplo_no_facturera=i

    plt.figure()
    plt.scatter(X_r2[ejemplo_facturera, 0], X_r2[ejemplo_facturera, 0],
			c=color_[ejemplo_facturera],label='Factureras')
    plt.scatter(X_r2[ejemplo_no_facturera, 0], X_r2[ejemplo_no_facturera,
			0], c=color_[ejemplo_no_facturera],label='No factureras')
    for i in range(len(M_reducida)):
        plt.scatter(X_r2[i, 0], X_r2[i, 0], c=color_[i])#, label=target_name)
    plt.title(u'Direccion de maxima discriminacion')
    plt.legend(loc=2)
    plt.savefig('direccion-discriminacion1.png')

    plt.figure()
    plt.scatter(X_r2[ejemplo_facturera, 0], X_r2[ejemplo_facturera, 0],
			c=color_[ejemplo_facturera],label='Factureras')
    plt.scatter(X_r2[ejemplo_no_facturera, 0], X_r2[ejemplo_no_facturera,
			0], c=color_[ejemplo_no_facturera],label='No factureras')
    for i in range(len(M_reducida)):
        plt.scatter(X_r2[i, 0], X_r2[i, 0]+((-1)**i)*5*np.random.rand(),
			c=color_[i])#, label=target_name)
    plt.title(u'Direccion de maxima discriminacion \n'
			u'con una perturbacion aleatoria en la vertical')
    plt.legend(loc=2)
    plt.savefig('direccion-discriminacion2.png')

    global prediccion_lda
    global transformacion_lda
    prediccion_lda=[]
    transformacion_lda={}
    for i in range(len(casos_a_predecir)):
        prediccion_lda.append(clf.predict(casos_a_predecir[i]))
        transformacion_lda[i]=clf.transform(casos_a_predecir[i])


    print ('bondad por crossvalidation: '+str(np.mean(scores)))

