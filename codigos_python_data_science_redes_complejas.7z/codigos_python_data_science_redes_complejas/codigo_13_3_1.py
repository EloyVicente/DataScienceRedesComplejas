# -*- coding: utf-8 -*-

import scipy.signal
import scipy.io.wavfile
import matplotlib.pyplot as plt
import glob
import numpy as np
from matplotlib.mlab import griddata
from mpl_toolkits.mplot3d.axes3d import *
from matplotlib import cm

ratio_muestra,X=scipy.io.wavfile.read('ruta/classical.00000.wav')
A=scipy.signal.spectrogram(X, fs=ratio_muestra)

x=[]
y=[]
z=[]

for i in range(len(A[2])):
    for j in range(len(A[2][i])):
        x.append(A[0][i])
        y.append(A[1][j])
        z.append(A[2][i][j])

xi = np.linspace(min(x), max(x))
yi = np.linspace(min(y), max(y))
X, Y = np.meshgrid(xi, yi)
Z = griddata(x, y, z, xi, yi)

fig = plt.figure()
ax = Axes3D(fig)
ax.set_xlabel('Frecuencia (hz)')
ax.set_ylabel('Tiempo (s)')
ax.set_zlabel(u'Amplitud')
ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.jet,linewidth=1, antialiased=True)

plt.plot
plt.title(u'Espectrograma clasica')
plt.savefig('espectrograma_3D_clasica.png',dpi=400)
plt.show()

