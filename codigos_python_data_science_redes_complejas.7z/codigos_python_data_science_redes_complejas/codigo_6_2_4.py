# -*- coding: utf-8 -*-


import Queue

def recorrido_anchura(G,s):

    Q=Queue.Queue()
    visitados=[s]
    Q.put(s)
    while not Q.empty():
        s=Q.get()
        for v in G.sucesores(s):
            if v not in visitados:
                visitados.append(v)
                Q.put(v)

    return visitados


def recorrido_profundidad(G,s,visitados=[]):

    visitados.append(s)

    for v in G.sucesores(s):

        if v not in set(visitados):
            recorrido_profundidad(G,v,visitados)

    return visitados