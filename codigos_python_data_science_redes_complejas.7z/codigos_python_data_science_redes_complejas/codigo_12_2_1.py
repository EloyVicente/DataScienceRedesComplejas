# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-

from pytagcloud import create_tag_image, make_tags
from pytagcloud.lang.counter import get_tag_counts


def nube_de_palabras(texto):

    L=file(texto)
    txt=L.read()
    L.close()
    tags = make_tags(get_tag_counts(txt), maxsize=60)
    create_tag_image(tags, 'nube_palabras.png', size=(900, 900), fontname='Lobster')