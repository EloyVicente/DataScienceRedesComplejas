# -*- coding: utf-8 -*-

def Dijkstra(G,s,t=None,infinito=sys.maxint):

    global S
    S=set()
    D={}
    for v in G.V:
        D[v]=infinito

    D[s]=0
    while len(S)!=len(G.V):
        dist_min=infinito

        for v in G.V:
            if v not in S and D[v]<dist_min:
                u=v
                dist_min=D[u]
        S.add(u)

        for v in G.sucesores(u):
            if v not in S:
                D[v]=np.min([D[v],D[u]+G.pesos[(u,v)]])

    if t==None:
        return D

    else:
        return D[t]
