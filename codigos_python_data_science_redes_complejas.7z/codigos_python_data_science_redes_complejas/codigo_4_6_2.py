# -*- coding: utf-8 -*-
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import pylab
import numpy as np
import scipy

# Generar nube de puntos

sigma=[0.2,0.2,0.2]
n=100
N=3*n
a = scipy.zeros([3*n])
b = scipy.zeros([3*n])

for i in range(n):
    a[i] = np.random.normal(2, sigma[0])
    b[i] =np.random.normal(2, sigma[0])

for i in range(n):
    a[i+n] = np.random.normal(4, sigma[1])
    b[i+n] =np.random.normal(4, sigma[1])

for i in range(n):
    a[i+2*n] = np.random.normal(4, sigma[2])
    b[i+2*n] =np.random.normal(1, sigma[2])

Kmeans(3)

# Obtener los clusters de k-medias:

d=np.zeros((N, 3))
for i in range(N):
    for j in range(3):
        d[i,j]=np.sqrt((a[i]-centroides[j,0])**2+(b[i]-centroides[j,1])**2)

C=[[],[],[]]
for i in range(N):
    for j in range(3):
        if d[i,j]==min(d[i,0],d[i,1],d[i,2]):
            C[j].append((a[i],b[i]))

# Ordenar los puntos según los clusters y recalcular la matriz de distancias

U=list(C[0])+list(C[1])+list(C[2])
D=np.zeros((3*n,3*n))
for i in range(300):
        for j in range(3*n):
                D[i,j]=np.sqrt((U[i][0]-U[j][0])**2+(U[i][1]-U[j][1])**2)

# Visualización de la matriz de distancias.

fig = pylab.figure()

plt.subplot(121)
plt.scatter(a,b)
plt.title('Nube de \n''300 puntos en tres clusters')

plt.subplot(122)
im=plt.imshow(D)
plt.title('Matriz de distancia con\n''los clusters ordenados \n' 'obtenidos de k-medias')
axcolor = fig.add_axes([0.925,0.1,0.01,0.8])
pylab.colorbar(im, cax=axcolor)

plt.show()


