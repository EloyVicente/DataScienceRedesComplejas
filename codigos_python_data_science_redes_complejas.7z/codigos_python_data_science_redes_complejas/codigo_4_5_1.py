# -*- coding: utf-8 -*-

from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import pylab
import numpy as np
import scipy
import skfuzzy as skf

def generar_nube(sigma):
    global n,N
    n=1000
    N=3*n
    global a,b
    a = scipy.zeros([3*n])
    b = scipy.zeros([3*n])

    P=[[],[],[]]


    for i in range(n):
        a[i] = np.random.normal(2, sigma[0])
        b[i] =np.random.normal(2, sigma[0])
        P[0].append((a[i],b[i]))

    for i in range(n):
        a[i+n] = np.random.normal(4, sigma[1])
        b[i+n] =np.random.normal(4, sigma[1])
        P[1].append((a[i+n],b[i+n]))
    for i in range(n):
        a[i+2*n] = np.random.normal(4, sigma[2])
        b[i+2*n] =np.random.normal(1, sigma[2])
        P[2].append((a[i+2*n],b[i+2*n]))

    return a,b,P

R=generar_nube((0.6,0.6,0.6))

data=np.array((R[0],R[1])) # Datos a clasificar
c=3 # Numero de clusters
m=2 # parametro de intensificacion de la borrosidad.
error=0.1 # Cota de la diferencia de fitnes entre las dos ultimas iteraciones
maxiter=1000 # Numero maximo de iteraciones.

clases=skf.cmeans(data, c, m, error, maxiter, seed=None)
centros=clases[1]

color=np.zeros(N)
for i in range(N):
    color[i]=np.max([clases[1][j][i] for j in range(3)])


t=np.linspace(0,1,N)

fig=plt.figure()
plt.scatter(R[0],R[1],c=color)

plt.title('fuzzy c-means \n' 'sobre nube de puntos')
axcolor = fig.add_axes([0.925,0.1,0.01,0.8])
pylab.colorbar(cax=axcolor)
plt.show()

plt.figure()
plt.plot(clases[1][0])
plt.plot(clases[1][1])
plt.plot(clases[1][2])
plt.show()