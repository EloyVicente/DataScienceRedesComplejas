# -*- coding: utf-8 -*-

import graph_tool.all as gt

g=gt.collection.data['lesmis']
color=g.new_vertex_property("vector<float>")
g.vertex_properties["color"]=color
for v in g.vertices():
        color[v]=[0,0.1,0.1]

pos=gt.sfdp_layout(g)
vp,ep=gt.betweenness(g)

for v in g.vertices():
    if vp[v]>0.08:
        color[v]=[1,0,0]
    else:
        color[v]=[0.7,0.7,0.7]

gt.graph_draw(g,pos=pos,vertex_font_size=9,vertex_size=10,output_size=(400,400),vertex_fill_color=color,
                              output="lesmis_intermediarios.png",fmt="png",dpi=1000)
