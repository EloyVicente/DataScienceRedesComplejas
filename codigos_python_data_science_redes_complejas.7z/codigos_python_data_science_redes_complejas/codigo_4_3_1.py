# -*- coding: utf-8 -*-

from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import numpy as np
import scipy

n=1000

a = scipy.zeros([3*n])
b = scipy.zeros([3*n])

for i in range(n):
    a[i] = np.random.normal(2, 0.5)
    b[i] =np.random.normal(2, 0.5)
for i in range(n):
    a[i+n] = np.random.normal(4, 0.5)
    b[i+n] =np.random.normal(4, 0.5)
for i in range(n):
    a[i+2*n] = np.random.normal(4, 0.5)
    b[i+2*n] =np.random.normal(1, 0.5)



def Kmeans(clusters):

   L=np.array([a,b]).transpose()
   datos_reducidos = L
   kmeans = KMeans(init='k-means++', n_clusters=clusters, n_init=5)
   kmeans.fit(datos_reducidos)

   h = .01

   x_min, x_max = datos_reducidos[:, 0].min()-1, datos_reducidos[:, 0].max()+1
   y_min, y_max = datos_reducidos[:, 1].min()-1, datos_reducidos[:, 1].max()+1
   xx, yy = np.meshgrid(np.arange(x_min, x_max, h), np.arange(y_min, y_max, h))
   Z = kmeans.predict(np.c_[xx.ravel(), yy.ravel()])
   Z = Z.reshape(xx.shape)

   plt.close ()
   plt.figure()
   plt.clf()

   plt.imshow(Z, interpolation='nearest',
               extent=(xx.min(), xx.max(), yy.min(), yy.max()),
               cmap=plt.cm.Paired,
               aspect='auto', origin='lower')

   plt.plot(datos_reducidos[:, 0], datos_reducidos[:, 1], 'k.')
   global centroides
   centroides = kmeans.cluster_centers_

   plt.scatter(centroides[:, 0], centroides[:, 1],
               marker='x', s=169, linewidths=3,
               color='w', zorder=10)

   plt.title('Algoritmo K-means clustering \n '
                u'Los centroides estan marcados con una X blanca')
   plt.xlim(x_min, x_max)
   plt.ylim(y_min, y_max)
   plt.xticks(())
   plt.yticks(())

   plt.show()

Kmeans(clusters=3)