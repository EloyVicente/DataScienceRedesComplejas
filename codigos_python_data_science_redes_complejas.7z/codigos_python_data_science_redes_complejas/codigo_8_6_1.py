# -*- coding: utf-8 -*-

import numpy as np

A=np.array(((0,1,0,0),(0,0,0.5,0.5),(1,0,0,0),(0.5,0,0.5,0)))
n=1000000

v_0=np.array((0.25,0.25,0.25,0.25))
B=np.dot(v_0.transpose(),A)

for i in range(n):
    B=np.dot(B,A)

print B
print np.sum(B)