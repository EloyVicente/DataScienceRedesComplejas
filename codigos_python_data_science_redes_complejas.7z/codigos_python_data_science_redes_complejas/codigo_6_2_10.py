# -*- coding: utf-8 -*-
def ordenacion_topologica_con_origen(G,s,visitados,f):

    global contador
    visitados.append(s)

    for v in G.sucesores(s):
        if v not in visitados:
            ordenacion_topologica_con_origen(G,v,visitados,f)

    contador-=1
    f[contador]=s


def  ordenacion_topologica(G):

    global contador
    visitados=[]
    h=[None]*len(G.V)
    contador=len(G.V)

    for v in G.V:
        if v not in visitados:
            ordenacion_topologica_con_origen(G,v,visitados,h)

    return h