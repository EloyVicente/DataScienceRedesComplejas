# -*- coding: utf-8 -*-


def clausura_transitiva(G):

    alcanzables={}

    for u in G.V:
        alcanzables[u]=recorrido_anchura(G,u)

    V_=G.V
    E_=[]

    for u in alcanzables.keys():
        for v in V_:
            if v in alcanzables[u] and v!=u:
                E_.append((u,v))

    grafo_clausura=grafo(V_,E_)

    return grafo_clausura
