# -*- coding: utf-8 -*-
import numpy as np
from matplotlib import pyplot as plt
import matplotlib
import pylab

n=2000
N=20
mu1=0.4
mu2=0.6
conjunto={}
for i in range(n):
    conjunto[i]=np.random.randint(2)

indicador={}

for i in range(n):
    if conjunto[i]==0:
        indicador[i]=np.random.normal(mu1,np.sqrt(0.01))
    else:
        indicador[i]=np.random.normal(mu2,np.sqrt(0.01))

def curva_roc(conjunto,indicador):

    S=[]
    E=[]

    x=np.linspace(0,1,N)
    for i in x:
        VP=[]
        FP=[]
        VN=[]
        FN=[]
        for k in range(n):
            if indicador[k]<i:
                if conjunto[k]==0:
                    VP.append(k)
                else:
                    FP.append(k)
            else:
                if conjunto[k]==1:
                    VN.append(k)
                else:
                    FN.append(k)

        S.append(len(VP)/float((len(VP)+len(FN))))
        E.append(len(VN)/float((len(FP)+len(VN))))
    Uno_menos_E=np.ones(N)-E
    B={}
    for i in range (N):
        if S[i]<Uno_menos_E[i]:
            S[i]=1-S[i]
            Uno_menos_E[i]=1-Uno_menos_E[i]
        B[Uno_menos_E[i]]=S[i]
    B1=[]
    B2=[]
    B1=sorted(B.keys())
    for i in range(len(B)):
        B2.append(B[B1[i]])

    integral=0
    for i in range(len(B))[1:]:
        a=abs((B1[i]-B1[i-1])*((B2[i-1])+(B2[i]-B2[i-1])/2))
        integral=integral+a
    print integral

    V1=np.array(B1)
    V2=np.array(B2)
    a1=V1*V1
    a2=np.sqrt((V2-np.ones(len(V2)))*(V2-np.ones(len(V2))))
    distancias=np.array(np.sqrt(a1+a2))
    m=min(distancias)
    for i in range(len(B)):
        if distancias[i]==m:
            punto_nivel=[B1[i],B2[i]]
            nivel=x[i]
    print punto_nivel

    plt.plot(B1,B2,label='Curva ROC')
    plt.plot(S,S)
    plt.annotate('AUC='+str(integral),(0.6,0.2),(0.6,0.2))
    plt.annotate(u'Punto optimo', xytext=(0.5,0.4), xy=(punto_nivel),
            arrowprops=dict(facecolor='black', shrink=0.05, width=0.1))
    plt.annotate(u'de clasificacion',xytext=(0.5,0.35), xy=(0.5,0.35))
    plt.annotate(u'Nivel optimo='+str(nivel),xytext=(0.5,0.30), xy=(0.5,0.30))
    plt.legend(loc=4)
    plt.savefig('ROC3.png')