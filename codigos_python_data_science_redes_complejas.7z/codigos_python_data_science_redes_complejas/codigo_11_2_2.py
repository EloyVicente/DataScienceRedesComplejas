# -*- coding: utf-8 -*-

from sklearn import manifold
import numpy as np
import matplotlib.pyplot as plt

def mds():


    n=len(usuarios.keys())
    A=np.zeros((n,n))

    for i in range(n):
        for j in range(n):
            #print ('usuario'+str(i+1))
            A[i][j]=1-pearson(usuarios['usuario'+str(i+1)],usuarios['usuario'+str(j+1)])

    mds = manifold.MDS(n_components=2, max_iter=3000, eps=1e-9,
                   dissimilarity="precomputed", n_jobs=1)

    nombres=usuarios.keys()
    nombres.sort()

    pos = mds.fit(A).embedding_
    plt.scatter(pos[:,0],pos[:,1])
    for i in range(8):
        print i
        plt.text(pos[i,0]+np.random.rand()/100,pos[i,1]+np.random.rand()/100,nombres[i])

    plt.title(u'Proyeccion MDS de usuarios')