# -*- coding: utf-8 -*-

import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

def percolacion_erdos_renyi(n,m):
    g=nx.Graph()
    for i in range(n):
        u=g.add_node(i)
    grado_medio=[]
    porcentaje_componente_grande=[]
    for i in range(m):

        a=np.random.randint(n)
        b=np.random.randint(n)
        if a!=b and (a,b) not in g.edges() and (b,a) not in g.edges():
            g.add_edge(a,b)

        if i%100==0 and i>0:
            plt.figure()
            nx.draw(g,node_size=40)
            plt.savefig('percolacion '+str(i)+'.png',dpi=400)
            plt.title(u'Iteracion '+str(i)+', Grado medio = '+str(grado_medio[i-1]))

        grados=[]
        for v in g.nodes():
            grados.append(g.degree(v))
        grado_medio.append(np.mean(grados))
        componentes = list(nx.connected_component_subgraphs(g))

        longitudes_componentes=[]
        for h in componentes:
            longitudes_componentes.append(nx.number_of_nodes(h))

        porcentaje_componente_grande.append(np.max(longitudes_componentes)/float(n))


    plt.figure()
    plt.plot(grado_medio,porcentaje_componente_grande)
    plt.title(u'Umbral de percolacion')
    plt.savefig('umbralpercolacion.png',dpi=400)

    return g, grado_medio, porcentaje_componente_grande

