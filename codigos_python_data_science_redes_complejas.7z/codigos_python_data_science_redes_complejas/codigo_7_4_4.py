# -*- coding: utf-8 -*-

def comparacion_longitud_clustering(g):


    c=nx.clustering(g)

    C=np.mean(c.values())
    L=nx.average_shortest_path_length(g)


    return C,L


C=[]
L=[]
g=grafo_watts_strogatz(n=1000, k=5, alpha=0,dibujo=False)
R0=comparacion_longitud_clustering(g)

C0=R0[0]
L0=R0[1]

print ('Finalizado grafo inicial')
plt.figure(figsize=(8,5))

alphas=[0.0001,0.00025,0.0005,0.00075,0.001,0.0025,0.005,0.0075,0.01,0.025,0.05,0.075,0.1,0.25,0.5,0.75,1]

for i in alphas:

    g=grafo_watts_strogatz(n=1000, k=5, alpha=i,dibujo=False)
    R=comparacion_longitud_clustering(g)
    print ('Finalizado grafo '+str(i))


    C.append(R[0]/C0)
    L.append(R[1]/L0)
    plt.scatter(np.log(i),R[0]/C0,color='k')
    plt.scatter(np.log(i),R[1]/L0,color='r')

plt.scatter(np.log(i),R[0]/C0,color='k',label='Coef. Clustering')
plt.scatter(np.log(i),R[1]/L0,color='r',label='Longitud media')
plt.legend()
plt.title(u'Comparacion de coeficientes de clustering y longitud media \n''en redes de Watts-Strogatz')
plt.savefig('comparacion_watts_strogatz.png',dpi=400)