# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-

import graph_tool.all as gt
import matplotlib.pyplot as plt
import numpy as np

g = gt.collection.data['polblogs']
g = gt.GraphView(g, vfilt=gt.label_largest_component(gt.GraphView(g, directed=False)))
state = gt.BlockState(g, B=g.num_vertices(), deg_corr=True)
state = gt.multilevel_minimize(state, B=2)
gt.graph_draw(g, pos=g.vp["pos"], vertex_fill_color=state.get_blocks(), output="polblogs_agg.png")

ee, h, a = gt.hits(g)

A=[]
H=[]
Ap=[]
Hp=[]

for v in g.vertices():
    A.append(a[v])
    H.append(h[v])

for v in g.vertices():
    if a[v]>np.percentile(A,98):
        Ap.append(v)
    if h[v]>np.percentile(H,98):
        Hp.append(v)

grado_entrada=[]
grado_salida=[]

for v in Hp:
    grado_entrada.append(v.in_degree())
    grado_salida.append(v.out_degree())
for v in Ap:
    grado_entrada.append(v.in_degree())
    grado_salida.append(v.out_degree())

plt.plot(grado_entrada,label='g.entrada')
plt.plot(grado_salida,label='g.salida')
plt.axvline(x=25, ymin =0.0 , ymax = 40 , linewidth =4, color='r')
plt.legend(loc=4,fancybox=True, framealpha=0.5)
plt.annotate('Authorities', xy=(7, 38))
plt.annotate('Hubs', xy=(35, 38))
plt.savefig('comparacion_hub_auth.png')
