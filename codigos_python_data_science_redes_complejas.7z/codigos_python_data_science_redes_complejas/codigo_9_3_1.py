# -*- coding: utf-8 -*-

import numpy as np
import graph_tool.all as gt
import numpy as np
from matplotlib import pyplot as plt
import matplotlib
import pylab

l=gt.collection.data["polbooks"]
vp,ep=gt.betweenness(l)
intermed=[ep[e] for e in l.edges()]
umbral=np.percentile(intermed,98)

def girvan_newman(l,umbral):

    g=l
    vp,ep=gt.betweenness(g)
    intermed=[ep[e] for e in g.edges()]
    p=np.max(intermed)
    k=0
    while p>umbral:
        print p
        vp,ep=gt.betweenness(g)
        intermed=[ep[e] for e in g.edges()]
        p=np.max(intermed)
        filtro_arco=g.new_edge_property('bool')
        g.edge_properties["filtro_arco"]=filtro_arco

        for e in g.edges():
            if ep[e]==p:
                filtro_arco[e]=False

            else:
                filtro_arco[e]=True

        g.set_edge_filter(filtro_arco)

        gt.graph_draw(g,vertex_font_size=9,vertex_size=10,#vertex_text=nombre, #pos=pos,
                          output_size=(300,300),
                             output="girvan_newman"+str(k)+".png",fmt="png")
        k=k+1

    return l