import numpy as np
import pylab as pl
import matplotlib.pyplot as plt

datos=np.loadtxt('iris.txt')

X_r=datos[:,0:4]

##########################Calculo de autovalores y autovectores####

X=X_r-X_r.mean(0)
CovX=np.dot(X.transpose(),X)


lambd , vec = np.linalg.eig(CovX)

a=lambd[0]/(sum(lambd))
b=lambd[1]/(sum(lambd))

v1=vec[:,0]
v2=vec[:,1]

print ('Porcentaje de varianza explicada para los dos primeros componentes:'), a,b

print ('componentes principales:'), vec

############################## Rotacion  y Proyeccion ###########
A=list(range(150))
B=list(range(150))
for i in range(150):
    A[i]=np.dot(X[i],v1)
    B[i]=np.dot(X[i],v2)

##############################Visualizacion######################

target_name=['setosa', 'versicolor', 'virginica']
plt.figure('scatter') # Crea una ventana titulada 'scatter'

t=list(range(150))
a=list(range(150))
for i in range(150):
    if datos[i,4]==0:
        t[i]='r'
    elif datos[i,4]==1:
        t[i]='g'
    else:
        t[i]='b'
    #t[i]=datos[i,4]


plt.figure('figura pca')

plt.scatter(A,B,c=t)

plt.scatter(A[25],B[25],c='r',label='setosa')
plt.scatter(A[75],B[75],c='g',label='versicolor')
plt.scatter(A[125],B[125],c='b',label='virginica')


plt.legend(loc = 1)  

pl.title('PCA sobre Iris Data Base')
plt.show()




