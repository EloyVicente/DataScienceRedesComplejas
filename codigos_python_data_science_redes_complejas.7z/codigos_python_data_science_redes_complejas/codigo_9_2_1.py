# -*- coding: utf-8 -*-

import numpy as np
import graph_tool.all as gt
from matplotlib import pyplot as plt
import pylab
from sklearn import manifold
import scipy.cluster.hierarchy as sch
from mpl_toolkits.mplot3d import Axes3D
from sklearn.cluster import KMeans

g=gt.collection.data["polbooks"]
grafpos=gt.sfdp_layout(g)
n=len(set(g.vertices()))
A=np.zeros((n,n))
for v in g.vertices():
    for w in g.vertices():
        A[v,w]=gt.shortest_distance(g,v,w)

def dendrograma(g,A):

    global Z
    global asignacion
    print A
    fig=plt.figure()
    Y=sch.linkage(A,method='centroid')
    Z=sch.dendrogram(Y)
    plt.title('Dendrograma de los nodos del grafo')
    plt.savefig('dendrogramagrafo.png')
    fig.show()
    asignacion={}
    k=0
    global lista1
    global lista2
    global lista3
    lista1=[]
    lista2=[]
    lista3=[]
    k=0
    for i in Z['color_list']:
        if i=='g':
            lista1.append(Z['ivl'][int(k)])
        elif i=='r':
            lista2.append(Z['ivl'][int(k)])
        elif i=='c':
            lista3.append(Z['ivl'][int(k)])
        k=k+1

    color=g.new_vertex_property("vector<float>")
    g.vertex_properties["color"]=color

    for v in g.vertices():
        if str(g.vertex_index[v]) in lista1:
            color[v]=[0,1,0]
        elif str(g.vertex_index[v]) in lista2:
            color[v]=[1,0,0]
        elif str(g.vertex_index[v]) in lista3:
            color[v]=[0,0,1]

    gt.graph_draw(g,vertex_font_size=9,vertex_size=5, pos=grafpos,
                          output_size=(500,500),
                             output="polbooks1.png",fmt="png")

    gt.graph_draw(g,vertex_font_size=9,vertex_size=5, vertex_fill_color=color, pos=grafpos,
                          output_size=(500,500),
                             output="polbooks2.png",fmt="png")
