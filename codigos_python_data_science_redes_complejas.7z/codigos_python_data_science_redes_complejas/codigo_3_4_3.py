# -*- coding: utf-8 -*-


import numpy as np
import pylab as pl
import matplotlib.pyplot as plt
from sklearn import manifold


datos=np.loadtxt('tomillares.txt')
X=datos.transpose()
jaccard=np.zeros((len(X),len(X)))
distancia=np.zeros((len(X),len(X)))
N=len(X)


for i in range(N):
    for j in range(N):
        jaccard[i,j]=np.dot(X[i],X[j])/(sum(X[i])+sum(X[j])-np.dot(X[i],X[j]))


for i in range(N):
    for j in range(N):
        distancia[i,j]=np.sqrt(jaccard[i,i]-2*jaccard[i,j]+jaccard[j,j])

seed = np.random.RandomState(seed=3)
mds = manifold.MDS(n_components=2, max_iter=3000, eps=1e-9,
      random_state=seed, dissimilarity="precomputed",
                   n_jobs=1)
pos = mds.fit(distancia).embedding_
target_name=[u'Estacion 1',u'Estacion 2',u'Estacion 3',
             u'Estacion 4',u'Estacion 5',u'Estacion 6',
             u'Estacion 7',u'Estacion 8']
plt.figure('scatter')
plt.scatter(pos[:,0],pos[:,1])
for i in range(N):
    plt.text(pos[i,0],pos[i,1]+0.05,target_name[i], fontsize = 10,
             horizontalalignment='center', verticalalignment='center')
plt.title(u'MDS metrico sobre 8 estaciones ecologicas del Cabo de Gata\n'
          u'(presencia de tomillares en rocas magmaticas acidas)')

plt.show()