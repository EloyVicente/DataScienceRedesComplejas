# -*- coding: utf-8 -*-

import numpy as np
import pylab as pl
import matplotlib.pyplot as plt
from sklearn import manifold


datos=np.loadtxt('bovino.txt')
seed = np.random.RandomState(seed=3)
mds = manifold.MDS(n_components=2, max_iter=3000, eps=1e-9,
      random_state=seed, dissimilarity="precomputed",
                   n_jobs=1,metric=False)
pos = mds.fit(datos).embedding_
print('stress=',mds.fit(datos).stress_)
target_name=['Alistana Sanabresa',u'Asturiana montana','Asturiana Valles',
             u'Blanca Cacerena','Cachena','Caldelana',
             u'Cardena Andaluza','Frieiresa','Lamiana','Morucha',
             'Rubia gallega','Sayaguesa','Vianesa']
plt.figure('scatter')
plt.scatter(pos[:,0],pos[:,1])
for i in range(len(datos)):
    plt.text(pos[i,0],pos[i,1]+0.00001,target_name[i], fontsize = 10,
             horizontalalignment='center', verticalalignment='center')
plt.title(u'MDS no metrico sobre distancias geneticas de razas bovinas espanolas')

plt.show()