# -*- coding: utf-8 -*-

import numpy as np
from matplotlib import pyplot as plt
from sklearn.neighbors import NearestNeighbors
from sklearn.neighbors import KNeighborsClassifier
from sklearn import cross_validation

N=100
sd=1
x1=np.random.normal(2,sd,N)
y1=np.random.normal(2,sd,N)
z1=np.zeros(N)

x2=np.random.normal(5,sd,N)
y2=np.random.normal(5,sd,N)
z2=np.ones(N)
plt.xlim([-2, 8])
plt.ylim([-2, 10])
plt.scatter(x1,y1,c='b',label='Clase 0')
plt.scatter(x2,y2,c='r',label='Clase 1')
plt.legend(loc=2)
plt.title('Puntos para clasificar')

color=[]
for i in range(N):
    color.append('b')

for i in range(N):
    color.append('r')



def knn_libreria(n):
    
    X=[[x1[i],y1[i]] for i in range(N)]
    X=X+[[x2[i],y2[i]] for i in range(N)]
    Z=list(z1)+list(z2)

    knn=KNeighborsClassifier(n_neighbors=n)
    scores = cross_validation.cross_val_score(knn, X, np.array(Z), cv=10)
    #print ('bondad por crossvalidation: '+str(np.mean(scores)))
    return np.mean(scores)

def determinacion_n_vecinos(R):

    bondad=[]
    for i in range(R):
        bondad.append(knn_libreria(i+1))


    plt.plot(bondad,label='prop. aciertos')
    plt.xlabel(u'Numero de vecinos')

    plt.legend(loc=4)

    plt.title(u'Proporcion de aciertos segun numero de vecinos \n' u'(por validacion cruzada)')

    plt.savefig('knnvecinos.png')
